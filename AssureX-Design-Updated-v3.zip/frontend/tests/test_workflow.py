from backend.decision.workflow import *

def base():
    return ({"label":"Valid Claim","confidence":0.90},{"label":"Valid Claim","confidence":0.88},{"comparison":"Strong Match","consistency_status":"Consistent","confidence_difference":0.02},{"blocked":False,"manual_review_flags":[]},{"blocked":False,"manual_review_flags":[]})

def test_summary_excludes_decision():
    s=generate_claim_summary({"product":{"name":"Phone","serialNumber":"SN1"},"fault":{"category":"Screen Crack"},"evidence":{"documentIds":["d1"]}})
    assert s["excludes_predictions"] and s["excludes_decision"] and "Valid Claim" not in s["text"]

def test_preparation():
    p=prepare_claim({}, {"missing_documents":[]}, {"serial_verification":{"status":"MATCH"}})
    assert p["ready"] and p["checklist"]["serial_verified"]

def test_approve():
    assert decide_claim(*base())["decision"] == "Approve"

def test_block_reject():
    a=list(base()); a[3]={"blocked":True,"hard_block_reasons":["WARRANTY_EXPIRED"]}
    assert decide_claim(*a)["decision"] == "Reject"

def test_manual_on_disagreement():
    a=list(base()); a[2]={"comparison":"Model Disagreement","consistency_status":"Inconsistent"}
    assert decide_claim(*a)["decision"] == "Manual Review"

def test_explanation():
    d=decide_claim(*base()); e=explain_decision(d,base()[3],base()[4],base()[2]); assert e["decision"]=="Approve" and e["reasons"]

def test_review_and_override():
    r=create_review_record("AXC-1","u1","Approve","checked evidence")
    o=apply_review_override({"decision":"Manual Review"},r,"reviewer")
    assert o["finalDecision"]=="Approve" and o["originalDecision"]=="Manual Review"

def test_override_rejects_user():
    r=create_review_record("AXC-1","u1","Reject")
    try: apply_review_override({"decision":"Approve"},r,"user")
    except PermissionError: return
    assert False
