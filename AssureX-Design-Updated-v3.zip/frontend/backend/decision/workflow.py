"""AssureX requirements XXXII-XXXVII decision workflow.

No new ML inference is performed here. The module consumes the outputs from the
existing Python/TM models and XXV-XXXI rule engine.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

ALLOWED_DECISIONS = {"Likely Valid", "Likely Invalid", "Manual Review Required", "Approve", "Reject", "Manual Review"}


def _s(v: Any) -> str:
    return "" if v is None else str(v).strip()


def _label(model: Optional[Dict[str, Any]]) -> str:
    return _s((model or {}).get("label") or (model or {}).get("prediction"))


def _confidence(model: Optional[Dict[str, Any]]) -> Optional[float]:
    try:
        return float((model or {}).get("confidence"))
    except (TypeError, ValueError):
        return None


def generate_claim_summary(claim: Dict[str, Any]) -> Dict[str, Any]:
    """XXXII: factual claim summary only; never inserts model decisions."""
    product = claim.get("product") or {}
    fault = claim.get("fault") or {}
    repair = claim.get("repairHistory") or claim.get("repair_history") or {}
    evidence = claim.get("evidence") or {}
    parts = []
    name = _s(product.get("name") or claim.get("productName"))
    if name: parts.append(f"Product: {name}")
    serial = _s(product.get("serialNumber") or claim.get("serialNumber"))
    if serial: parts.append(f"Serial number: {serial}")
    category = _s(product.get("category") or claim.get("productCategory"))
    if category: parts.append(f"Category: {category}")
    damage = _s(fault.get("category") or claim.get("damageCategory") or claim.get("damage"))
    if damage: parts.append(f"Reported fault/damage: {damage}")
    desc = _s(fault.get("description") or claim.get("faultDescription"))
    if desc: parts.append(f"Description: {desc}")
    repaired = repair.get("previouslyRepaired")
    if repaired not in (None, "", False, "no", "No"):
        parts.append(f"Previous repair: {_s(repair.get('repairCount') or 'reported')}")
    doc_ids = evidence.get("documentIds") or []
    parts.append(f"Linked evidence documents: {len(doc_ids) if isinstance(doc_ids, list) else 0}")
    return {
        "version": "32.0.0",
        "type": "factual_claim_summary",
        "text": " ".join(parts) if parts else "Claim information is available for review.",
        "fields_used": [p.split(":", 1)[0] for p in parts],
        "excludes_predictions": True,
        "excludes_decision": True,
    }


def prepare_claim(claim: Dict[str, Any], warranty: Dict[str, Any], fraud: Dict[str, Any]) -> Dict[str, Any]:
    """XXXIII: deterministic preparation checklist for reviewer/decision engine."""
    missing = warranty.get("missing_documents") or fraud.get("missing_documents") or []
    contradictions = warranty.get("contradictions") or fraud.get("contradictions") or []
    serial = fraud.get("serial_verification") or {}
    duplicate = fraud.get("duplicate_claim") or {}
    docdup = fraud.get("duplicate_document") or {}
    return {
        "version": "33.0.0",
        "ready": not missing and not contradictions and not duplicate.get("is_duplicate") and not docdup.get("is_duplicate"),
        "checklist": {
            "required_documents_present": not bool(missing),
            "contradictions_clear": not bool(contradictions),
            "serial_verified": serial.get("status") in (None, "MATCH", "VERIFIED"),
            "no_duplicate_claim": not bool(duplicate.get("is_duplicate")),
            "no_duplicate_document": not bool(docdup.get("is_duplicate")),
            "warranty_evaluated": bool(warranty),
        },
        "missing_items": list(missing) if isinstance(missing, list) else [missing] if missing else [],
        "review_notes": [
            "Resolve every BLOCKED or MANUAL_REVIEW rule before approval." if (missing or contradictions) else "No outstanding rule finding was supplied."
        ],
    }


def decide_claim(python_model: Dict[str, Any], teachable_machine: Dict[str, Any], comparison: Dict[str, Any], warranty: Dict[str, Any], fraud: Dict[str, Any]) -> Dict[str, Any]:
    """XXXIV: deterministic final decision over existing model/rule outputs."""
    hard = list(warranty.get("hard_block_reasons") or []) + list(fraud.get("hard_block_reasons") or [])
    manual = list(warranty.get("manual_review_flags") or []) + list(fraud.get("manual_review_flags") or [])
    status = _s(comparison.get("consistency_status") or comparison.get("consistency"))
    py_label, tm_label = _label(python_model), _label(teachable_machine)
    py_conf, tm_conf = _confidence(python_model), _confidence(teachable_machine)
    if hard or warranty.get("blocked") is True or fraud.get("blocked") is True:
        decision = "Reject"
        basis = "Hard warranty or fraud/business-rule blocker."
    elif manual or status in ("Inconsistent", "Uncertain") or py_label != tm_label:
        decision = "Manual Review"
        basis = "A rule, model-consistency, or evidence condition requires human review."
    elif py_label == tm_label == "Valid Claim" and (py_conf is None or py_conf >= 0.55) and (tm_conf is None or tm_conf >= 0.55):
        decision = "Approve"
        basis = "Both configured models support a valid-claim result and no blocking rule was supplied."
    elif "Invalid Claim" in (py_label, tm_label):
        decision = "Reject"
        basis = "The configured model outputs include an invalid-claim result and no manual-review condition overrides it."
    else:
        decision = "Manual Review"
        basis = "Model evidence is insufficient for an automatic decision."
    return {
        "version": "34.0.0", "decision": decision, "basis": basis,
        "hard_block_count": len(hard), "manual_review_count": len(manual),
        "model_labels": {"python": py_label, "teachable_machine": tm_label},
        "model_confidences": {"python": py_conf, "teachable_machine": tm_conf},
        "rule_blockers": hard, "manual_review_flags": manual,
        "automatic": decision != "Manual Review",
    }


def explain_decision(decision: Dict[str, Any], warranty: Dict[str, Any], fraud: Dict[str, Any], comparison: Dict[str, Any]) -> Dict[str, Any]:
    """XXXV: auditable explanation tied to concrete inputs."""
    reasons = []
    if decision.get("rule_blockers"): reasons.extend([f"Rule blocker: {x}" for x in decision["rule_blockers"]])
    if decision.get("manual_review_flags"): reasons.extend([f"Manual-review flag: {x}" for x in decision["manual_review_flags"]])
    if comparison.get("comparison"): reasons.append(f"Model comparison: {comparison['comparison']}")
    if comparison.get("confidence_difference") is not None: reasons.append(f"Confidence difference: {comparison['confidence_difference']}")
    if not reasons: reasons.append("No blocking or manual-review rule finding was supplied; decision follows the configured model outputs.")
    return {"version":"35.0.0", "decision":decision.get("decision"), "reasons":reasons, "source_sections":["models","warranty_rules","fraud_checks","model_comparison"], "generatedAt":datetime.now(timezone.utc).isoformat()}


def create_review_record(claim_id: str, reviewer_id: str, decision: str, comments: str = "") -> Dict[str, Any]:
    """XXXVI: canonical manual-review record."""
    if decision not in ALLOWED_DECISIONS: raise ValueError("Invalid review decision")
    if not _s(reviewer_id): raise ValueError("reviewer_id is required")
    return {"claimId":claim_id,"reviewerId":reviewer_id,"reviewDecision":decision,"reviewComments":_s(comments),"reviewStatus":"completed","reviewedAt":datetime.now(timezone.utc).isoformat(),"workflowVersion":"36.0.0"}


def apply_review_override(predicted: Dict[str, Any], review: Dict[str, Any], role: str) -> Dict[str, Any]:
    """XXXVII: only reviewer/admin may override a prediction; preserve original."""
    if role not in ("reviewer", "admin"): raise PermissionError("Only reviewer or admin can override a decision")
    review_decision = _s(review.get("reviewDecision"))
    if review_decision not in ALLOWED_DECISIONS: raise ValueError("Invalid review decision")
    original = predicted.get("decision") or predicted.get("finalDecision") or "Manual Review"
    return {
        **predicted,
        "finalDecision": review_decision,
        "reviewOverride": True,
        "originalDecision": original,
        "review": review,
        "canonicalReviewDecision": {"Approve":"Likely Valid","Reject":"Likely Invalid","Manual Review":"Manual Review Required"}.get(review_decision, review_decision),
        "decisionSource": "human_review_override",
        "workflowVersion": "37.0.0",
    }
