import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / 'backend'))
from model.comparison import compare_predictions
from model.analysis_result import attach_comparison


def model(label, confidence):
    return {'label': label, 'confidence': confidence}


def test_strong_consistent_match():
    r = compare_predictions(model('Valid Claim', .91), model('Valid Claim', .86))
    assert r['predictions_match'] is True
    assert r['comparison'] == 'Strong Match'
    assert r['consistency_status'] == 'Consistent'
    assert r['confidence_difference'] == .05


def test_disagreement_is_not_repredicted():
    r = compare_predictions(model('Valid Claim', .80), model('Manual Review', .70))
    assert r['predictions_match'] is False
    assert r['comparison'] == 'Model Disagreement'
    assert r['consistency_status'] == 'Inconsistent'


def test_large_confidence_gap_is_uncertain():
    r = compare_predictions(model('Valid Claim', .99), model('Valid Claim', .50))
    assert r['comparison'] == 'Uncertain Result'
    assert r['consistency_status'] == 'Uncertain'


def test_attach_does_not_replace_model_outputs():
    original = {
        'python_model': model('Invalid Claim', .77),
        'teachable_machine': model('Invalid Claim', .75),
    }
    py_before = original['python_model'].copy()
    tm_before = original['teachable_machine'].copy()
    out = attach_comparison(original)
    assert out['python_model'] == py_before
    assert out['teachable_machine'] == tm_before
    assert out['comparison']['comparison'] == 'Strong Match'
    assert out['confidence_comparison']['difference'] == .02
    assert out['consistency']['status'] == 'Consistent'
