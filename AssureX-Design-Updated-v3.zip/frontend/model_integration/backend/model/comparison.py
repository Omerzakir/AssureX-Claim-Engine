"""AssureX XXII-XXIV: compare existing model outputs only.

This module performs no inference. It consumes the prediction/confidence objects
already produced by the Python and Teachable Machine runtimes.
"""
from __future__ import annotations

VERSION = "22.0.0"
STRONG_MATCH_THRESHOLD = 0.10
ACCEPTABLE_MATCH_THRESHOLD = 0.20
WEAK_MATCH_THRESHOLD = 0.35


def _label(output: dict) -> str:
    value = output.get("label")
    if value is None:
        raise ValueError("Model output is missing label")
    return str(value)


def _confidence(output: dict) -> float:
    try:
        value = float(output["confidence"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Model output is missing numeric confidence") from exc
    if not 0.0 <= value <= 1.0:
        raise ValueError("Model confidence must be between 0 and 1")
    return value


def compare_predictions(python_model: dict, teachable_machine: dict) -> dict:
    """Return XXII-XXIV results without invoking either model."""
    python_label = _label(python_model)
    tm_label = _label(teachable_machine)
    python_conf = _confidence(python_model)
    tm_conf = _confidence(teachable_machine)
    confidence_difference = round(abs(python_conf - tm_conf), 10)
    same_prediction = python_label == tm_label

    if same_prediction and confidence_difference <= STRONG_MATCH_THRESHOLD:
        comparison = "Strong Match"
    elif same_prediction and confidence_difference <= ACCEPTABLE_MATCH_THRESHOLD:
        comparison = "Acceptable Match"
    elif same_prediction and confidence_difference <= WEAK_MATCH_THRESHOLD:
        comparison = "Weak Match"
    elif not same_prediction and confidence_difference <= WEAK_MATCH_THRESHOLD:
        comparison = "Model Disagreement"
    else:
        comparison = "Uncertain Result"

    if same_prediction and confidence_difference <= WEAK_MATCH_THRESHOLD:
        consistency_status = "Consistent"
    elif not same_prediction and confidence_difference <= WEAK_MATCH_THRESHOLD:
        consistency_status = "Inconsistent"
    else:
        consistency_status = "Uncertain"

    return {
        "version": VERSION,
        "python_prediction": python_label,
        "teachable_machine_prediction": tm_label,
        "predictions_match": same_prediction,
        "python_confidence": python_conf,
        "teachable_machine_confidence": tm_conf,
        "confidence_difference": confidence_difference,
        "comparison": comparison,
        "consistency_status": consistency_status,
        "thresholds": {
            "strong_match_max_difference": STRONG_MATCH_THRESHOLD,
            "acceptable_match_max_difference": ACCEPTABLE_MATCH_THRESHOLD,
            "weak_match_max_difference": WEAK_MATCH_THRESHOLD,
        },
    }
