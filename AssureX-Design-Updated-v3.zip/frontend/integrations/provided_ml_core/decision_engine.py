"""
AssureX Claim Engine - Final Decision Engine
-------------------------------------------------
Combines:
  1. Python classification model prediction + per-class confidence
  2. Google Teachable Machine prediction + per-class confidence
     (real TM inference happens in the browser-exported model; here we
      expose `teachable_machine_predict()` as the single integration point
      -- swap the stub body for a call to your exported TM model, e.g.
      via tensorflowjs/tflite/keras .h5, and everything downstream works
      unchanged)
  3. Warranty rule-engine result
  4. Missing documents / contradictions / duplicate flags

...into the SRS-mandated three-way outcome: Likely Valid, Likely Invalid,
or Manual Review Required, with a full decision explanation.
"""

import json
import joblib
import numpy as np
import pandas as pd
import sys

sys.path.insert(0, "/home/claude/assurex")
from rules.rule_engine import Claim, ClaimLedger, evaluate_warranty_rules

MODEL_DIR = "/home/claude/assurex/model"

best_model = joblib.load(f"{MODEL_DIR}/best_model.pkl")
scaler = joblib.load(f"{MODEL_DIR}/scaler.pkl")
encoders = joblib.load(f"{MODEL_DIR}/label_encoders.pkl")
feature_cols = joblib.load(f"{MODEL_DIR}/feature_columns.pkl")
label_map = joblib.load(f"{MODEL_DIR}/label_map.pkl")
inv_label_map = {v: k for k, v in label_map.items()}

STRONG_MATCH_THRESHOLD = 0.10
ACCEPTABLE_MATCH_THRESHOLD = 0.20
WEAK_MATCH_THRESHOLD = 0.35
MIN_CONFIDENCE_THRESHOLD = 0.55


def engineer_features_single(row: dict) -> dict:
    row = dict(row)
    row["Remaining_Warranty_Months"] = row["Warranty_Duration"] - row["Product_Age_Months"]
    row["Out_Of_Warranty"] = int(row["Remaining_Warranty_Months"] < 0)
    row["Documents_Complete"] = int(row["Missing_Documents_Count"] == 0)
    row["High_Risk_Repair"] = int(row["Previous_Repair_Unauthorized"] == 1 and row["Repair_History_Count"] >= 2)
    row["Late_Report"] = int(row["Fault_To_Claim_Delay_Days"] > 30)
    row["Risk_Score"] = (
        row["Missing_Documents_Count"]
        + 2 * (1 - row["Serial_Number_Match"])
        + 2 * row["Contradiction_Flag"]
        + 2 * row["Duplicate_Claim_Flag"]
        + row["Late_Report"]
        + 2 * row["Out_Of_Warranty"]
    )
    return row


def python_model_predict(claim_dict: dict):
    row = engineer_features_single(claim_dict)
    df = pd.DataFrame([row])
    for col, le in encoders.items():
        val = df.at[0, col]
        if val not in le.classes_:
            val = le.classes_[0]
        df[col] = le.transform([val])
    X = df[feature_cols]
    X_scaled = scaler.transform(X)
    proba = best_model.predict_proba(X_scaled)[0]
    pred_class = int(np.argmax(proba))
    return {
        "predicted_class": inv_label_map[pred_class],
        "confidence_scores": {inv_label_map[i]: round(float(p), 4) for i, p in enumerate(proba)},
        "top_confidence": round(float(proba[pred_class]), 4),
    }


def teachable_machine_predict(claim_dict: dict):
    """
    STUB — replace with real inference against your exported Google
    Teachable Machine model (e.g. load the .h5/.tflite and run the
    Claim Summary Card image through it). For demonstration purposes
    this simulates a plausible second, independently-trained model by
    reusing the Python model's probabilities with a bit of jitter, so
    the comparison logic below can be exercised end-to-end.
    """
    py_result = python_model_predict(claim_dict)
    rng = np.random.default_rng(abs(hash(claim_dict.get("Claim_ID", "x"))) % (2**32))
    noisy = {k: max(0.01, v + rng.normal(0, 0.08)) for k, v in py_result["confidence_scores"].items()}
    total = sum(noisy.values())
    noisy = {k: round(v / total, 4) for k, v in noisy.items()}
    pred_class = max(noisy, key=noisy.get)
    return {
        "predicted_class": pred_class,
        "confidence_scores": noisy,
        "top_confidence": noisy[pred_class],
    }


def compare_models(py_result: dict, tm_result: dict):
    same_class = py_result["predicted_class"] == tm_result["predicted_class"]
    conf_diff = abs(py_result["top_confidence"] - tm_result["top_confidence"])

    if same_class and conf_diff <= STRONG_MATCH_THRESHOLD:
        status = "Strong Match"
    elif same_class and conf_diff <= ACCEPTABLE_MATCH_THRESHOLD:
        status = "Acceptable Match"
    elif same_class and conf_diff <= WEAK_MATCH_THRESHOLD:
        status = "Weak Match"
    elif not same_class and conf_diff <= WEAK_MATCH_THRESHOLD:
        status = "Model Disagreement"
    else:
        status = "Uncertain Result"

    return {"classes_match": same_class, "confidence_difference": round(conf_diff, 4), "status": status}


def final_decision(claim_dict: dict, claim_obj: Claim, ledger: ClaimLedger):
    py_result = python_model_predict(claim_dict)
    tm_result = teachable_machine_predict(claim_dict)
    comparison = compare_models(py_result, tm_result)
    rules_result = evaluate_warranty_rules(claim_obj, ledger)

    supporting, opposing = [], []

    if rules_result["rules_failed"]:
        opposing.extend(rules_result["rules_failed"])
    if rules_result["manual_review_flags"]:
        opposing.extend(rules_result["manual_review_flags"])
    if rules_result["warnings"]:
        opposing.extend(rules_result["warnings"])
    supporting.extend(rules_result["rules_passed"])

    low_confidence = py_result["top_confidence"] < MIN_CONFIDENCE_THRESHOLD or tm_result["top_confidence"] < MIN_CONFIDENCE_THRESHOLD

    if rules_result["rules_failed"]:
        final = "Likely Invalid"
    elif rules_result["manual_review_flags"] or comparison["status"] in ("Model Disagreement", "Uncertain Result") or low_confidence:
        final = "Manual Review Required"
    elif py_result["predicted_class"] == "Valid Claim" and tm_result["predicted_class"] == "Valid Claim":
        final = "Likely Valid"
    elif py_result["predicted_class"] == "Invalid Claim" and tm_result["predicted_class"] == "Invalid Claim":
        final = "Likely Invalid"
    else:
        final = "Manual Review Required"

    return {
        "claim_id": claim_dict.get("Claim_ID"),
        "python_model": py_result,
        "teachable_machine": tm_result,
        "model_comparison": comparison,
        "warranty_rules": rules_result,
        "final_decision": final,
        "decision_explanation": {
            "supporting_factors": supporting,
            "opposing_factors": opposing,
            "additional_evidence_required": rules_result["missing_documents"],
        },
    }


if __name__ == "__main__":
    sample = {
        "Claim_ID": "DEMO001", "Product_Category": "Electronics", "Product_Age_Months": 8,
        "Warranty_Duration": 12, "Extended_Warranty": 0, "Purchase_Price": 500,
        "Damage_Type": "Component Failure", "Repair_History_Count": 0,
        "Previous_Repair_Unauthorized": 0, "Serial_Number_Match": 1,
        "Missing_Documents_Count": 0, "Fault_To_Claim_Delay_Days": 5,
        "Contradiction_Flag": 0, "Duplicate_Claim_Flag": 0,
    }
    claim_obj = Claim(
        claim_id="DEMO001", product_category="Electronics", product_age_months=8,
        warranty_duration=12, extended_warranty=False, damage_type="Component Failure",
        repair_history_count=0, previous_repair_unauthorized=False,
        serial_number_entered="SN1", serial_number_on_record="SN1",
        has_receipt=True, has_warranty_card=True, has_product_photo=True, has_serial_evidence=True,
        fault_date="2026-06-01", claim_submission_date="2026-06-06", purchase_date="2025-11-01",
        fault_to_claim_delay_days=5,
    )
    ledger = ClaimLedger()
    result = final_decision(sample, claim_obj, ledger)
    print(json.dumps(result, indent=2))
