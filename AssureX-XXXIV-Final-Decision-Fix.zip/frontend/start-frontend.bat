@echo off
cd /d "%~dp0"
echo AssureX frontend: http://localhost:8080/login.html
start "" "http://localhost:8080/login.html"
py -m http.server 8080 || python -m http.server 8080
