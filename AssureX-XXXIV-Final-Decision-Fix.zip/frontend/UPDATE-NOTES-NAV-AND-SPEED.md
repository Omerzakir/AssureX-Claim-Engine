# AssureX navigation, appearance and load optimizations

Base: `AssureX-Role-Based-Final-UI.zip` (the latest supplied version in this conversation).

Changes are intentionally restricted to frontend presentation, initial loading and data query efficiency. Existing Firebase project configuration, collections, form fields, product CRUD, warranty calculation and OCR result structures are unchanged.

- **Products:** load the shared role guard, Firebase app/auth/data service and notification service. Load the three Firebase SDK bundles once instead of twice. The role-dependent sidebar now resolves normally, then renders the correct six links for user/employee. The current page is marked Products. Initial product fetching waits for authorization; filters are locally debounced. Extract original inline page CSS into `css/products-page.css` for browser caching.
- **Documents:** use the Dashboard's main content wrapper, heading hierarchy, navigation shell, card surfaces, buttons and responsive light/dark theme. Move existing vault CSS to a separate cacheable sheet. Preserve upload/replace/download/delete/OCR/verification handlers. PDF.js and Tesseract.js load **on OCR click only**. Document list is fetched after role resolution and is reused when clicking a record; local search is debounced. Employee records are restricted to the signed-in account at the frontend query layer.
- **Warranties:** apply the same Dashboard-themed cards and 4 count cards derived from real registered product records, with responsive layout. Reuse one warranty policy load per refresh instead of a Firestore policy fetch per product. Employee product queries are user-scoped. Fetch only once after role resolution.
- **Appearance:** standalone Products/Documents topbar appearance button responds, as on the other pages; the existing bottom-right theme control remains. Existing notification and sign-out upgrade retained.

Checks: 25 automated Python tests pass; JavaScript syntax and local asset references in modified pages checked. A live Firebase session and page-by-page browser network timing were not available in this environment; no numerical performance improvement is claimed. Firestore rules still require deployment and should be tested with all roles.
