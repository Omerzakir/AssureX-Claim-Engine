# AssureX Compliance Matrix

This matrix tracks the supplied requirements after the integration update.

## Fully implemented in the package (excluding trained ML/TM artifacts)

- I-II: Authentication/RBAC hooks, customer/employee/reviewer/admin role support and profile management
- III-IV: Product and warranty management modules
- V-VII: Evidence upload, OCR extraction and verification
- VIII-IX: Warranty tracking and expiry alert logic
- X-XIV: Claim creation, claim information, evidence, repair history and document organization
- XV-XVI: Validation/pre-processing modules
- XX: Neutral Claim Summary Card generation
- XXII-XXIV: Model comparison, confidence difference and consistency classification
- XXV-XXXI: Warranty rules, configurable policies, serial verification, contradiction, missing-document and duplicate checks
- XXXII-XXXIII: Claim summary and preparation assistance
- XXXIV-XXXV: Decision engine and explanation
- XXXVI-XXXVII: Manual review and reviewer override/audit structures
- XXXVIII-XXXIX: Status tracking and notification logic
- XL-XLI: User/admin dashboards
- XLII-XLV: Search/filter/report/export modules present in the existing UI
- XLVI-XLVII: Firestore storage and audit modules
- XLVIII: Model-version schema and result fields
- XLIX-L: Error handling, monitoring and anomaly structures

## Intentionally pending trained artifacts

### XVII-XIX and XXI
The common dataset contract, Python model runtime, confidence interface and Teachable Machine runtime are implemented, but the trained model files are intentionally omitted as requested.

Install the Python artifacts under `model_integration/models/python/` and the Teachable Machine artifacts under `model_integration/models/teachable_machine/`.

Once installed, `POST /api/claims/analyze` executes the full pipeline without any UI redesign.

## Important behavior when models are absent

The API does **not** fabricate a prediction. It returns `503 MODEL_ARTIFACTS_NOT_INSTALLED`, and the existing claim UI safely preserves the claim and routes it to `Manual Review Required`.
