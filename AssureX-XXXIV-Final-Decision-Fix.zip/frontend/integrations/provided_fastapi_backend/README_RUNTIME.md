# AssureX Backend ML Runtime

This package contains only runtime files required by the AssureX Claim Engine ML/decision workflow described in the SRS.

Included:
- Python trained model artifacts and preprocessing artifacts
- Final decision engine
- Warranty/rule engine and configurable warranty policies
- Google Teachable Machine exported model and runtime adapters
- Claim Summary Card generator
- Python and Node runtime dependency manifests

Intentionally excluded from this runtime package:
- model training scripts
- training/validation/testing datasets
- dataset generators
- model comparison reports and charts
- sample claim cards
- Python cache files
- development/demo-only files

SRS runtime mapping:
- XVI: preprocessing/model artifacts used by decision engine
- XVIII-XIX: saved Python classifier + class probabilities
- XX: Claim Summary Card generation
- XXI-XXIV: Teachable Machine inference + model comparison
- XXV-XXIX: warranty rules, serial/missing-document/contradiction checks
- XXX-XXXI: duplicate claim/document checks through ClaimLedger
- XXXII-XXXV: final decision and explanation

The uploaded `assurex.zip` supplied for backend integration contained only an empty `assurex/` directory, so no existing API/database/authentication files could be preserved or merged from that archive.
