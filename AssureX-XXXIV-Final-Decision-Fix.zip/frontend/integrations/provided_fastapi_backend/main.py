"""AssureX FastAPI backend for the ML + rule-based claim engine."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field

from assurex.decision_engine import (
    build_claim_from_dict,
    final_decision,
    python_model_predict,
    teachable_machine_predict,
    validate_claim_dict,
)
from assurex.rules.rule_engine import ClaimLedger

APP_ROOT = Path(__file__).resolve().parent

app = FastAPI(
    title="AssureX Claim Engine API",
    version="2.0.0",
    description=(
        "FastAPI integration layer for the AssureX Python ML classifier, "
        "Google Teachable Machine, warranty rules, duplicate checks, and "
        "the final three-way claim decision."
    ),
)

# The frontend can be hosted separately during development. For production,
# replace '*' with the exact deployed frontend origin(s).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Runtime-only ledger. Replace its storage methods with Firebase/database
# persistence when connecting the existing application database.
ledger = ClaimLedger()


class TMResult(BaseModel):
    model_config = ConfigDict(extra="allow")
    predicted_class: str
    confidence_scores: Dict[str, float]
    top_confidence: Optional[float] = None


class ClaimRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    Claim_ID: str
    Product_Category: str
    Product_Age_Months: int
    Warranty_Duration: int
    Extended_Warranty: bool
    Purchase_Price: float = Field(default=0)
    Damage_Type: str
    Repair_History_Count: int = 0
    Previous_Repair_Unauthorized: bool = False
    Serial_Number_Match: bool = True
    Missing_Documents_Count: int = 0
    Fault_To_Claim_Delay_Days: int = 0
    Contradiction_Flag: bool = False
    Duplicate_Claim_Flag: bool = False

    # Fields needed by the rule engine / richer SRS workflow.
    Serial_Number_Entered: str = ""
    Serial_Number_On_Record: str = ""
    Has_Receipt: bool = True
    Has_Warranty_Card: bool = True
    Has_Product_Photo: bool = True
    Has_Serial_Evidence: bool = True
    Fault_Date: str = "1970-01-01"
    Claim_Submission_Date: str = "1970-01-01"
    Purchase_Date: str = "1970-01-01"
    Document_Hashes: list[str] = Field(default_factory=list)

    def to_claim_dict(self) -> Dict[str, Any]:
        data = self.model_dump()
        # Keep the SRS/model input consistent even when only Serial_Number_Match
        # is supplied by the frontend.
        if not data["Serial_Number_Entered"] and not data["Serial_Number_On_Record"]:
            data["Serial_Number_Entered"] = "MATCHED" if data["Serial_Number_Match"] else "ENTERED"
            data["Serial_Number_On_Record"] = "MATCHED" if data["Serial_Number_Match"] else "RECORD"
        return data


class FullDecisionRequest(BaseModel):
    claim: ClaimRequest
    teachable_machine_result: Optional[TMResult] = None


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {"status": "ok", "service": "AssureX Claim Engine", "version": "2.0.0"}


@app.get("/api")
def api_info() -> Dict[str, Any]:
    return {
        "service": "AssureX Claim Engine API",
        "endpoints": [
            "POST /api/claims/python-predict",
            "POST /api/claims/teachable-machine",
            "POST /api/claims/decision",
            "POST /api/claims/validate",
        ],
    }


def _validate_or_422(claim: ClaimRequest) -> Dict[str, Any]:
    data = claim.to_claim_dict()
    try:
        validate_claim_dict(data)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return data


@app.post("/api/claims/python-predict")
def python_predict(claim: ClaimRequest) -> Dict[str, Any]:
    """Run the saved Python classifier and return every class probability."""
    data = _validate_or_422(claim)
    try:
        return python_model_predict(data)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/claims/teachable-machine")
async def teachable_machine(
    image: UploadFile = File(...),
) -> Dict[str, Any]:
    """Run the real bundled Teachable Machine model on an uploaded image."""
    suffix = Path(image.filename or "claim-image").suffix or ".jpg"
    content = await image.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded image is empty.")

    temp_path: Optional[str] = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(content)
            temp_path = tmp.name
        return teachable_machine_predict({}, image_path=temp_path)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    finally:
        if temp_path:
            try:
                Path(temp_path).unlink(missing_ok=True)
            except OSError:
                pass


@app.post("/api/claims/decision")
def decision(request: FullDecisionRequest) -> Dict[str, Any]:
    """Run the complete SRS claim-decision pipeline using a real TM result."""
    data = _validate_or_422(request.claim)
    if request.teachable_machine_result is None:
        raise HTTPException(
            status_code=422,
            detail="A real teachable_machine_result is required for /decision. "
            "Use /validate with an image for server-side TM inference.",
        )

    tm_result = request.teachable_machine_result.model_dump()
    try:
        claim_obj = build_claim_from_dict(data)
        return final_decision(data, claim_obj, ledger, tm_result=tm_result)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/claims/validate")
async def validate_claim(
    claim_json: str,
    image: Optional[UploadFile] = File(default=None),
) -> Dict[str, Any]:
    """Run the complete pipeline.

    claim_json: JSON string containing ClaimRequest-compatible data.
    image: optional claim-summary-card image. If supplied, the real TM model
    runs server-side. Otherwise claim_json must include teachable_machine_result.
    """
    try:
        payload = json.loads(claim_json)
        request = FullDecisionRequest.model_validate(payload)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Invalid claim_json: {exc}") from exc

    data = _validate_or_422(request.claim)
    temp_path: Optional[str] = None
    try:
        if image is not None:
            suffix = Path(image.filename or "claim-image").suffix or ".jpg"
            content = await image.read()
            if not content:
                raise HTTPException(status_code=400, detail="Uploaded image is empty.")
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(content)
                temp_path = tmp.name
            tm_kwargs = {"tm_image_path": temp_path}
        else:
            if request.teachable_machine_result is None:
                raise HTTPException(
                    status_code=422,
                    detail="Provide an image or a real teachable_machine_result.",
                )
            tm_kwargs = {"tm_result": request.teachable_machine_result.model_dump()}

        claim_obj = build_claim_from_dict(data)
        return final_decision(data, claim_obj, ledger, **tm_kwargs)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    finally:
        if temp_path:
            try:
                Path(temp_path).unlink(missing_ok=True)
            except OSError:
                pass


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
