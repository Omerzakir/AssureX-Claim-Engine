# AssureX FastAPI Backend

This package exposes the SRS-required AssureX claim engine through a REST API.

## Endpoints

- `GET /api/health` — runtime health check
- `POST /api/claims/python-predict` — Python classifier + all class probabilities
- `POST /api/claims/teachable-machine` — real TM inference from an uploaded image
- `POST /api/claims/decision` — complete decision using a real browser TM result
- `POST /api/claims/validate` — complete decision using either an uploaded image or browser TM result
- `GET /docs` — FastAPI interactive API documentation

## Run

1. Create/activate a Python virtual environment.
2. Install Python dependencies:

```bash
pip install -r requirements.txt
```

3. For server-side Teachable Machine image inference, install Node.js 18+ and:

```bash
cd assurex/teachable_machine
npm install
cd ../..
```

4. Start the API:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000` and interactive docs at `/docs`.

## Frontend integration

For browser TM inference, the frontend can run the exported TensorFlow.js model and send the three class confidence scores to `/api/claims/decision`.

For server-side TM inference, send `claim_json` plus the claim-summary-card image to `/api/claims/validate` as multipart form data.

## Important production note

`ClaimLedger` is intentionally in-memory in this runtime. It demonstrates the SRS duplicate-claim/document decision logic but does not survive process restarts or multiple API workers. Connect those ledger operations to the project's existing Firebase/database layer for persistent duplicate detection.

## SRS boundary

FastAPI is only the API/integration layer. The actual decision remains in the Python classifier, real Teachable Machine model, warranty rule engine, and final decision engine.
