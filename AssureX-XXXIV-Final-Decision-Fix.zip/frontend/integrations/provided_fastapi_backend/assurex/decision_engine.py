"""
AssureX Claim Engine - Final Decision Engine
=============================================
Production-ready fusion layer for:
  1. Python scikit-learn classification model
  2. Google Teachable Machine image model
  3. Warranty/business-rule engine
  4. Missing-document, contradiction and duplicate checks

The engine supports two Teachable Machine integration modes:
  A) Browser mode: pass the real TM prediction returned by the frontend.
  B) Local/server mode: pass a claim-summary-card image and this module calls
     tm_inference.js, which loads the real exported TFJS model.

No simulated/jittered TM prediction is used.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

import joblib
import numpy as np
import pandas as pd

try:
    from .rules.rule_engine import Claim, ClaimLedger, evaluate_warranty_rules
except ImportError:
    from rules.rule_engine import Claim, ClaimLedger, evaluate_warranty_rules


BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "model"
TM_DIR = BASE_DIR / "teachable_machine"
TM_RUNNER = TM_DIR / "tm_inference.js"
TM_MODEL_JSON = TM_DIR / "model.json"
TM_METADATA = TM_DIR / "metadata.json"

best_model = joblib.load(MODEL_DIR / "best_model.pkl")
scaler = joblib.load(MODEL_DIR / "scaler.pkl")
encoders = joblib.load(MODEL_DIR / "label_encoders.pkl")
feature_cols = joblib.load(MODEL_DIR / "feature_columns.pkl")
label_map = joblib.load(MODEL_DIR / "label_map.pkl")
inv_label_map = {int(v): k for k, v in label_map.items()}

with open(TM_METADATA, "r", encoding="utf-8") as f:
    TM_METADATA_JSON = json.load(f)
TM_LABELS = TM_METADATA_JSON.get("labels", ["Invalid Claim", "Manual Review", "Valid Claim"])

# These thresholds are intentionally explicit so they can be changed without
# rewriting the decision logic.
STRONG_MATCH_THRESHOLD = 0.10
ACCEPTABLE_MATCH_THRESHOLD = 0.20
WEAK_MATCH_THRESHOLD = 0.35
MIN_CONFIDENCE_THRESHOLD = 0.55


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y"}
    return bool(value)


def _normalise_probabilities(scores: Dict[str, Any], labels) -> Dict[str, float]:
    values = {label: max(0.0, float(scores.get(label, 0.0))) for label in labels}
    total = sum(values.values())
    if total <= 0:
        raise ValueError("Model returned no usable class probabilities.")
    return {label: round(value / total, 6) for label, value in values.items()}


def validate_claim_dict(claim: Dict[str, Any]) -> None:
    required = [
        "Claim_ID", "Product_Category", "Product_Age_Months", "Warranty_Duration",
        "Extended_Warranty", "Purchase_Price", "Damage_Type", "Repair_History_Count",
        "Previous_Repair_Unauthorized", "Serial_Number_Match", "Missing_Documents_Count",
        "Fault_To_Claim_Delay_Days", "Contradiction_Flag", "Duplicate_Claim_Flag",
    ]
    missing = [key for key in required if key not in claim]
    if missing:
        raise ValueError(f"Missing claim fields: {', '.join(missing)}")


def engineer_features_single(row: Dict[str, Any]) -> Dict[str, Any]:
    row = dict(row)
    row["Remaining_Warranty_Months"] = float(row["Warranty_Duration"]) - float(row["Product_Age_Months"])
    row["Out_Of_Warranty"] = int(row["Remaining_Warranty_Months"] < 0)
    row["Documents_Complete"] = int(int(row["Missing_Documents_Count"]) == 0)
    row["High_Risk_Repair"] = int(
        _as_bool(row["Previous_Repair_Unauthorized"]) and int(row["Repair_History_Count"]) >= 2
    )
    row["Late_Report"] = int(int(row["Fault_To_Claim_Delay_Days"]) > 30)
    row["Risk_Score"] = (
        int(row["Missing_Documents_Count"])
        + 2 * (1 - int(_as_bool(row["Serial_Number_Match"])))
        + 2 * int(_as_bool(row["Contradiction_Flag"]))
        + 2 * int(_as_bool(row["Duplicate_Claim_Flag"]))
        + row["Late_Report"]
        + 2 * row["Out_Of_Warranty"]
    )
    return row


def python_model_predict(claim_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Run the saved production scikit-learn model and return all class scores."""
    validate_claim_dict(claim_dict)
    row = engineer_features_single(claim_dict)
    df = pd.DataFrame([row])

    for col, encoder in encoders.items():
        value = df.at[0, col]
        if value not in encoder.classes_:
            raise ValueError(
                f"Unsupported value {value!r} for {col}. "
                f"Expected one of: {list(encoder.classes_)}"
            )
        df[col] = encoder.transform([value])

    X = df[feature_cols]
    X_scaled = scaler.transform(X)
    probabilities = best_model.predict_proba(X_scaled)[0]
    pred_index = int(np.argmax(probabilities))

    scores = {
        inv_label_map[i]: round(float(probabilities[i]), 6)
        for i in range(len(probabilities))
    }
    return {
        "model": "AssureX Python classification model",
        "predicted_class": inv_label_map[pred_index],
        "confidence_scores": scores,
        "top_confidence": round(float(probabilities[pred_index]), 6),
    }


def _validate_tm_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a real browser/server TM result before fusion."""
    if not isinstance(result, dict):
        raise ValueError("teachable_machine_result must be an object/dict.")
    scores = result.get("confidence_scores")
    predicted = result.get("predicted_class")
    if not isinstance(scores, dict) or not scores:
        raise ValueError("Teachable Machine result must contain confidence_scores.")
    if predicted not in TM_LABELS:
        raise ValueError(f"Unknown Teachable Machine class: {predicted!r}")
    normalized = _normalise_probabilities(scores, TM_LABELS)
    predicted = max(normalized, key=normalized.get)
    return {
        "model": "Google Teachable Machine",
        "predicted_class": predicted,
        "confidence_scores": normalized,
        "top_confidence": round(normalized[predicted], 6),
    }


def teachable_machine_predict(
    claim_dict: Dict[str, Any],
    *,
    image_path: Optional[str] = None,
    tm_result: Optional[Dict[str, Any]] = None,
    node_binary: str = "node",
    timeout_seconds: int = 30,
) -> Dict[str, Any]:
    """
    Obtain a REAL Teachable Machine prediction.

    Preferred browser integration:
        teachable_machine_predict(claim, tm_result=frontend_prediction)

    Local/server integration:
        teachable_machine_predict(claim, image_path="/path/card.png")

    The local mode invokes the bundled tm_inference.js runner and exported
    model.json/weights.bin. There is deliberately no fake fallback.
    """
    if tm_result is not None:
        return _validate_tm_result(tm_result)

    if not image_path:
        raise ValueError(
            "A real Teachable Machine result or image_path is required. "
            "The engine no longer generates simulated TM predictions."
        )

    image = Path(image_path).expanduser().resolve()
    if not image.is_file():
        raise FileNotFoundError(f"TM input image not found: {image}")
    if not TM_RUNNER.is_file() or not TM_MODEL_JSON.is_file():
        raise FileNotFoundError("Bundled Teachable Machine runner/model is incomplete.")

    command = [node_binary, str(TM_RUNNER), str(image), str(TM_MODEL_JSON), str(TM_METADATA)]
    try:
        completed = subprocess.run(
            command,
            cwd=str(TM_DIR),
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(
            "Node.js is required for local Teachable Machine inference. "
            "Run `npm install` inside assurex/teachable_machine."
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("Teachable Machine inference timed out.") from exc

    if completed.returncode != 0:
        raise RuntimeError(
            "Teachable Machine inference failed: "
            + (completed.stderr.strip() or completed.stdout.strip())
        )

    try:
        raw = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"TM runner returned invalid JSON: {completed.stdout[:500]}") from exc
    return _validate_tm_result(raw)


def compare_models(py_result: Dict[str, Any], tm_result: Dict[str, Any]) -> Dict[str, Any]:
    """XXII-XXIV: canonical five-state SRS comparison contract."""
    same_class = py_result["predicted_class"] == tm_result["predicted_class"]
    confidence_difference = round(abs(py_result["top_confidence"] - tm_result["top_confidence"]), 6)
    min_confidence = min(py_result["top_confidence"], tm_result["top_confidence"])

    if min_confidence < MIN_CONFIDENCE_THRESHOLD:
        status = "Uncertain Result"
    elif same_class and confidence_difference <= STRONG_MATCH_THRESHOLD:
        status = "Strong Match"
    elif same_class and confidence_difference <= ACCEPTABLE_MATCH_THRESHOLD:
        status = "Acceptable Match"
    elif same_class and confidence_difference <= WEAK_MATCH_THRESHOLD:
        status = "Weak Match"
    else:
        status = "Model Disagreement"

    return {
        "classes_match": same_class,
        "python_prediction": py_result["predicted_class"],
        "teachable_machine_prediction": tm_result["predicted_class"],
        "python_confidence": py_result["top_confidence"],
        "teachable_machine_confidence": tm_result["top_confidence"],
        "confidence_difference": confidence_difference,
        "status": status,
        "consistency_status": status,
        "thresholds": {
            "strong_match_max_difference": STRONG_MATCH_THRESHOLD,
            "acceptable_match_max_difference": ACCEPTABLE_MATCH_THRESHOLD,
            "weak_match_max_difference": WEAK_MATCH_THRESHOLD,
            "minimum_confidence": MIN_CONFIDENCE_THRESHOLD,
        },
    }

def _humanize(code: str) -> str:
    return code.replace("_", " ").strip().capitalize()


def _decision_explanation(
    py_result: Dict[str, Any],
    tm_result: Dict[str, Any],
    comparison: Dict[str, Any],
    rules_result: Dict[str, Any],
    final: str,
) -> Dict[str, Any]:
    supporting = [_humanize(x) for x in rules_result["rules_passed"]]
    opposing = [_humanize(x) for x in rules_result["rules_failed"]]
    opposing.extend(_humanize(x) for x in rules_result["manual_review_flags"])
    opposing.extend(_humanize(x) for x in rules_result["warnings"])

    if comparison["classes_match"]:
        supporting.append(
            f"Both models predict {py_result['predicted_class']} "
            f"(Python {py_result['top_confidence']:.1%}, TM {tm_result['top_confidence']:.1%})."
        )
    else:
        opposing.append(
            f"Model disagreement: Python predicts {py_result['predicted_class']}, "
            f"while Teachable Machine predicts {tm_result['predicted_class']}."
        )

    if min(py_result["top_confidence"], tm_result["top_confidence"]) < MIN_CONFIDENCE_THRESHOLD:
        opposing.append(
            f"At least one model is below the {MIN_CONFIDENCE_THRESHOLD:.0%} confidence threshold."
        )

    return {
        "summary": f"Final outcome: {final}.",
        "supporting_factors": supporting,
        "opposing_factors": opposing,
        "additional_evidence_required": rules_result["missing_documents"],
        "model_evidence": {
            "python_prediction": py_result["predicted_class"],
            "python_confidence": py_result["top_confidence"],
            "teachable_machine_prediction": tm_result["predicted_class"],
            "teachable_machine_confidence": tm_result["top_confidence"],
            "agreement_status": comparison["status"],
        },
    }


def final_decision(
    claim_dict: Dict[str, Any],
    claim_obj: Claim,
    ledger: ClaimLedger,
    *,
    tm_result: Optional[Dict[str, Any]] = None,
    tm_image_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Run the complete AssureX decision pipeline."""
    py_result = python_model_predict(claim_dict)
    tm_result_final = teachable_machine_predict(
        claim_dict,
        image_path=tm_image_path,
        tm_result=tm_result,
    )
    comparison = compare_models(py_result, tm_result_final)
    rules_result = evaluate_warranty_rules(claim_obj, ledger)

    low_confidence = (
        py_result["top_confidence"] < MIN_CONFIDENCE_THRESHOLD
        or tm_result_final["top_confidence"] < MIN_CONFIDENCE_THRESHOLD
    )

    # Priority order: hard rule failure -> manual review -> unanimous model
    # evidence. This prevents an ML prediction from overriding a deterministic
    # warranty violation.
    if rules_result["rules_failed"]:
        final = "Likely Invalid"
    elif (
        rules_result["manual_review_flags"]
        or comparison["status"] in {"Model Disagreement", "Uncertain Result"}
        or low_confidence
    ):
        final = "Manual Review Required"
    elif (
        py_result["predicted_class"] == "Valid Claim"
        and tm_result_final["predicted_class"] == "Valid Claim"
    ):
        final = "Likely Valid"
    elif (
        py_result["predicted_class"] == "Invalid Claim"
        and tm_result_final["predicted_class"] == "Invalid Claim"
    ):
        final = "Likely Invalid"
    else:
        final = "Manual Review Required"

    return {
        "engine_version": "2.0.0",
        "claim_id": claim_dict.get("Claim_ID"),
        "python_model": py_result,
        "teachable_machine": tm_result_final,
        "model_comparison": comparison,
        "warranty_rules": rules_result,
        "final_decision": final,
        "decision_explanation": _decision_explanation(
            py_result, tm_result_final, comparison, rules_result, final
        ),
    }


def build_claim_from_dict(claim: Dict[str, Any]) -> Claim:
    """Convert the application's claim payload into the rule-engine dataclass."""
    return Claim(
        claim_id=str(claim["Claim_ID"]),
        product_category=str(claim["Product_Category"]),
        product_age_months=int(claim["Product_Age_Months"]),
        warranty_duration=int(claim["Warranty_Duration"]),
        extended_warranty=_as_bool(claim["Extended_Warranty"]),
        damage_type=str(claim["Damage_Type"]),
        repair_history_count=int(claim["Repair_History_Count"]),
        previous_repair_unauthorized=_as_bool(claim["Previous_Repair_Unauthorized"]),
        serial_number_entered=str(claim.get("Serial_Number_Entered", "")),
        serial_number_on_record=str(claim.get("Serial_Number_On_Record", "")),
        has_receipt=_as_bool(claim.get("Has_Receipt", int(claim["Missing_Documents_Count"]) == 0)),
        has_warranty_card=_as_bool(claim.get("Has_Warranty_Card", True)),
        has_product_photo=_as_bool(claim.get("Has_Product_Photo", True)),
        has_serial_evidence=_as_bool(claim.get("Has_Serial_Evidence", True)),
        fault_date=str(claim.get("Fault_Date", "1970-01-01")),
        claim_submission_date=str(claim.get("Claim_Submission_Date", "1970-01-01")),
        purchase_date=str(claim.get("Purchase_Date", "1970-01-01")),
        fault_to_claim_delay_days=int(claim["Fault_To_Claim_Delay_Days"]),
        document_hashes=list(claim.get("Document_Hashes", [])),
    )


if __name__ == "__main__":
    # CLI demo intentionally requires a real TM image. It never fabricates a
    # Teachable Machine result.
    import argparse

    parser = argparse.ArgumentParser(description="Run the AssureX final decision engine.")
    parser.add_argument("--claim-json", required=True, help="Path to claim JSON payload.")
    parser.add_argument("--tm-image", required=True, help="Claim Summary Card image for TM inference.")
    args = parser.parse_args()

    with open(args.claim_json, "r", encoding="utf-8") as f:
        claim = json.load(f)

    validate_claim_dict(claim)
    claim_obj = build_claim_from_dict(claim)
    ledger = ClaimLedger()
    result = final_decision(claim, claim_obj, ledger, tm_image_path=args.tm_image)
    print(json.dumps(result, indent=2))
