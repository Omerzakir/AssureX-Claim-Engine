"""
AssureX Claim Engine - Claim Summary Card Generator
-------------------------------------------------------
Converts pre-processed claim data into a standardized visual "Claim Summary
Card" image, per SRS Step 7. This card intentionally contains ONLY claim
information (product age, warranty status, fault type, repair history,
document availability, serial-number status) and NEVER the Python model's
prediction, confidence score, or the final decision -- it is the independent
input fed to the separately-trained Google Teachable Machine model.

generate_variations() produces >=2 visual variations per card (layout /
font-size / color-scheme changes only -- never changing the underlying
claim information or its class), satisfying the SRS's requirement of at
least 2,100 training images for 1,050 training claims.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


def render_card(claim: dict, out_path: str, variation: int = 0):
    """
    claim: dict with keys like Product_Category, Product_Age_Months,
    Warranty_Duration, Damage_Type, Repair_History_Count,
    Missing_Documents_Count, Serial_Number_Match (bool)
    variation: 0 = default layout/theme, 1 = alt layout/theme, 2 = alt font/spacing
    """
    themes = [
        {"bg": "#ffffff", "accent": "#1f4e79", "font": "DejaVu Sans", "size": 11},
        {"bg": "#f5f5f0", "accent": "#7a2e2e", "font": "DejaVu Serif", "size": 12},
        {"bg": "#eef3f8", "accent": "#2e5a3e", "font": "DejaVu Sans", "size": 10},
    ]
    theme = themes[variation % len(themes)]

    fig, ax = plt.subplots(figsize=(4, 5))
    fig.patch.set_facecolor(theme["bg"])
    ax.set_facecolor(theme["bg"])
    ax.axis("off")

    ax.add_patch(mpatches.Rectangle((0, 0.92), 1, 0.08, color=theme["accent"]))
    ax.text(0.5, 0.96, "CLAIM SUMMARY CARD", ha="center", va="center",
            fontsize=theme["size"] + 3, color="white", fontweight="bold",
            fontfamily=theme["font"])

    lines = [
        f"Product Category: {claim['Product_Category']}",
        f"Product Age: {claim['Product_Age_Months']} months",
        f"Warranty Duration: {claim['Warranty_Duration']} months",
        f"Fault Type: {claim['Damage_Type']}",
        f"Repair History: {claim['Repair_History_Count']} repair(s)",
        f"Serial Number: {'Matched' if claim.get('Serial_Number_Match', 1) else 'Mismatch'}",
        f"Missing Documents: {claim['Missing_Documents_Count']}",
    ]
    y = 0.80
    for line in lines:
        ax.text(0.06, y, line, ha="left", va="center", fontsize=theme["size"],
                 color="#222222", fontfamily=theme["font"])
        y -= 0.10

    ax.add_patch(mpatches.Rectangle((0, 0), 1, 0.03, color=theme["accent"]))
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, facecolor=fig.get_facecolor())
    plt.close()


def generate_variations(claim: dict, out_dir: str, base_name: str, n_variations: int = 2):
    paths = []
    for v in range(n_variations):
        path = f"{out_dir}/{base_name}_v{v}.png"
        render_card(claim, path, variation=v)
        paths.append(path)
    return paths


if __name__ == "__main__":
    import pandas as pd
    df = pd.read_csv("/home/claude/assurex/data/train.csv").head(2)
    for _, row in df.iterrows():
        claim = row.to_dict()
        generate_variations(claim, "/home/claude/assurex/cards", f"sample_{claim['Claim_ID']}_{claim['Label'].replace(' ', '')}", 2)
    print("Sample cards generated.")
