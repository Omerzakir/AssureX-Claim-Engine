"""
AssureX Claim Engine - Warranty Rule Engine
-----------------------------------------------
Implements the SRS-required checks independently of the ML models:
  - Warranty expiry / coverage validation (policy-driven, not hard-coded)
  - Missing document detection
  - Contradiction detection
  - Duplicate claim detection (via a simple in-memory claim/document ledger)
  - Serial-number verification

Produces a structured result the decision engine can combine with the
Python model's prediction and the Google Teachable Machine's prediction.
"""

import json
import hashlib
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List

POLICY_FILE = Path(__file__).resolve().parent / "warranty_policies.json"
with open(POLICY_FILE, encoding="utf-8") as f:
    POLICIES = json.load(f)


@dataclass
class Claim:
    claim_id: str
    product_category: str
    product_age_months: int
    warranty_duration: int
    extended_warranty: bool
    damage_type: str
    repair_history_count: int
    previous_repair_unauthorized: bool
    serial_number_entered: str
    serial_number_on_record: str
    has_receipt: bool
    has_warranty_card: bool
    has_product_photo: bool
    has_serial_evidence: bool
    fault_date: str
    claim_submission_date: str
    purchase_date: str
    fault_to_claim_delay_days: int
    document_hashes: List[str] = field(default_factory=list)


class ClaimLedger:
    """Very small in-memory store standing in for the claims database,
    used purely to demonstrate duplicate-claim / duplicate-document detection."""
    def __init__(self):
        self.seen_claim_keys = set()
        self.seen_doc_hashes = set()

    def register_and_check_duplicate(self, claim: Claim) -> bool:
        key = (claim.product_category, claim.serial_number_entered, claim.damage_type)
        is_dup = key in self.seen_claim_keys
        self.seen_claim_keys.add(key)
        return is_dup

    def register_and_check_duplicate_docs(self, claim: Claim) -> bool:
        is_dup = any(h in self.seen_doc_hashes for h in claim.document_hashes)
        self.seen_doc_hashes.update(claim.document_hashes)
        return is_dup


def hash_document(file_bytes: bytes) -> str:
    return hashlib.sha256(file_bytes).hexdigest()


def evaluate_warranty_rules(claim: Claim, ledger: ClaimLedger) -> Dict:
    policy = POLICIES[claim.product_category]
    effective_warranty = claim.warranty_duration + (policy["extended_warranty_months"] if claim.extended_warranty else 0)

    rules_passed, rules_failed, warnings, manual_review_flags = [], [], [], []

    # 1. Warranty expiry
    if claim.product_age_months > effective_warranty:
        rules_failed.append("out_of_warranty")
    else:
        rules_passed.append("within_warranty_period")

    # 2. Fault coverage / exclusions
    if claim.damage_type in policy["exclusions"] and not claim.extended_warranty:
        rules_failed.append("excluded_damage_type")
    else:
        rules_passed.append("fault_covered_by_policy")

    # 3. Claim reporting period
    if claim.fault_to_claim_delay_days > policy["claim_reporting_period_days"]:
        warnings.append("late_claim_reporting")
    else:
        rules_passed.append("reported_within_deadline")

    # 4. Repair history / authorized service center
    if claim.previous_repair_unauthorized and claim.repair_history_count >= 3:
        rules_failed.append("excessive_unauthorized_repairs")
    elif claim.previous_repair_unauthorized:
        warnings.append("unauthorized_repair_on_record")
    else:
        rules_passed.append("repair_history_clean")

    # 5. Serial number verification
    serial_mismatch = claim.serial_number_entered.strip().lower() != claim.serial_number_on_record.strip().lower()
    if serial_mismatch:
        manual_review_flags.append("serial_number_mismatch")
    else:
        rules_passed.append("serial_number_verified")

    # 6. Missing document detection
    doc_flags = {
        "purchase_receipt": claim.has_receipt,
        "warranty_card": claim.has_warranty_card,
        "product_photo": claim.has_product_photo,
        "serial_number_evidence": claim.has_serial_evidence,
    }
    missing_docs = [name for name in policy["mandatory_documents"] if not doc_flags.get(name, True)]
    if len(missing_docs) >= 2:
        manual_review_flags.append("multiple_missing_documents")
    elif len(missing_docs) == 1:
        warnings.append("single_missing_document")
    else:
        rules_passed.append("all_mandatory_documents_present")

    # 7. Contradiction detection
    contradictions = []
    if claim.claim_submission_date < claim.purchase_date:
        contradictions.append("claim_date_before_purchase_date")
    if claim.fault_date < claim.purchase_date:
        contradictions.append("fault_date_before_purchase_date")
    if claim.fault_date > claim.claim_submission_date:
        contradictions.append("fault_date_after_submission_date")
    if contradictions:
        manual_review_flags.append("contradiction_detected")

    # 8. Duplicate detection
    is_duplicate_claim = ledger.register_and_check_duplicate(claim)
    is_duplicate_docs = ledger.register_and_check_duplicate_docs(claim)
    if is_duplicate_claim or is_duplicate_docs:
        manual_review_flags.append("duplicate_claim_suspected")

    return {
        "policy_used": claim.product_category,
        "effective_warranty_months": effective_warranty,
        "rules_passed": rules_passed,
        "rules_failed": rules_failed,
        "warnings": warnings,
        "manual_review_flags": manual_review_flags,
        "missing_documents": missing_docs,
        "contradictions": contradictions,
        "serial_mismatch": serial_mismatch,
        "is_duplicate_claim": is_duplicate_claim,
        "is_duplicate_documents": is_duplicate_docs,
    }
