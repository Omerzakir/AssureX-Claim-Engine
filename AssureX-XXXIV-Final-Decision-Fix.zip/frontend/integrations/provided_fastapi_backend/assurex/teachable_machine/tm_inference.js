#!/usr/bin/env node
/**
 * AssureX - real Google Teachable Machine TFJS inference adapter.
 *
 * Usage:
 *   node tm_inference.js IMAGE MODEL_JSON METADATA_JSON
 *
 * Dependencies are declared in package.json. The script returns JSON only,
 * making it safe for decision_engine.py to consume.
 */
const fs = require('fs');
const path = require('path');
const tf = require('@tensorflow/tfjs-node');

async function main() {
  const [, , imagePath, modelPath, metadataPath] = process.argv;
  if (!imagePath || !modelPath || !metadataPath) {
    throw new Error('Usage: node tm_inference.js IMAGE MODEL_JSON METADATA_JSON');
  }
  if (!fs.existsSync(imagePath)) throw new Error(`Image not found: ${imagePath}`);
  if (!fs.existsSync(modelPath)) throw new Error(`Model not found: ${modelPath}`);
  if (!fs.existsSync(metadataPath)) throw new Error(`Metadata not found: ${metadataPath}`);

  const metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
  const labels = metadata.labels || [];
  if (!labels.length) throw new Error('TM metadata contains no labels.');

  const modelUrl = 'file://' + path.resolve(modelPath);
  const model = await tf.loadLayersModel(modelUrl);
  const imageBuffer = fs.readFileSync(imagePath);
  let input = tf.node.decodeImage(imageBuffer, 3);
  input = tf.image.resizeBilinear(input, [224, 224]);
  input = input.toFloat().div(127.5).sub(1.0).expandDims(0);

  const output = model.predict(input);
  const tensor = Array.isArray(output) ? output[0] : output;
  const values = Array.from(await tensor.data());
  if (values.length !== labels.length) {
    throw new Error(`TM output size ${values.length} does not match ${labels.length} labels.`);
  }

  const total = values.reduce((a, b) => a + Number(b), 0);
  const probabilities = values.map(v => Number(v) / (total || 1));
  let bestIndex = 0;
  for (let i = 1; i < probabilities.length; i++) {
    if (probabilities[i] > probabilities[bestIndex]) bestIndex = i;
  }

  const confidence_scores = {};
  labels.forEach((label, i) => {
    confidence_scores[label] = Number(probabilities[i].toFixed(6));
  });

  console.log(JSON.stringify({
    predicted_class: labels[bestIndex],
    confidence_scores,
    top_confidence: Number(probabilities[bestIndex].toFixed(6)),
  }));

  tf.dispose([input, output]);
}

main().catch(err => {
  console.error(err.stack || err.message || String(err));
  process.exit(1);
});
