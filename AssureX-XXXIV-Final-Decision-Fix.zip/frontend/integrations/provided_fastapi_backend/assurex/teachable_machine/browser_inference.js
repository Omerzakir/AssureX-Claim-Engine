/**
 * AssureX browser adapter for the exported Google Teachable Machine model.
 *
 * Include TensorFlow.js before this file and point MODEL_URL at model.json.
 * The function returns the exact structure expected by decision_engine.py.
 */

export async function loadAssureXTM(modelUrl = './model.json', metadataUrl = './metadata.json') {
  if (!window.tf) {
    throw new Error('TensorFlow.js must be loaded before browser_inference.js');
  }

  const [model, metadata] = await Promise.all([
    window.tf.loadLayersModel(modelUrl),
    fetch(metadataUrl).then(r => {
      if (!r.ok) throw new Error(`Unable to load TM metadata: ${r.status}`);
      return r.json();
    })
  ]);

  const labels = metadata.labels || [];
  if (!labels.length) throw new Error('TM metadata contains no labels.');

  return {
    model,
    labels,
    async predict(imageElement) {
      const input = window.tf.tidy(() => {
        const pixels = window.tf.browser.fromPixels(imageElement);
        return window.tf.image.resizeBilinear(pixels, [224, 224])
          .toFloat().div(127.5).sub(1).expandDims(0);
      });

      try {
        const output = model.predict(input);
        const tensor = Array.isArray(output) ? output[0] : output;
        const values = Array.from(await tensor.data());
        const total = values.reduce((a, b) => a + Number(b), 0) || 1;
        const probabilities = values.map(v => Number(v) / total);
        let best = 0;
        for (let i = 1; i < probabilities.length; i++) {
          if (probabilities[i] > probabilities[best]) best = i;
        }

        const confidence_scores = {};
        labels.forEach((label, i) => {
          confidence_scores[label] = Number(probabilities[i].toFixed(6));
        });

        return {
          predicted_class: labels[best],
          confidence_scores,
          top_confidence: Number(probabilities[best].toFixed(6))
        };
      } finally {
        window.tf.dispose(input);
      }
    }
  };
}
