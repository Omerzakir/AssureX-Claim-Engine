# Diagnosis: why `model5.ipynb` couldn't pass 85%

## Reproduced baseline
Re-running the uploaded notebook's exact pipeline on `claim_dataset5.csv` (5,000 rows):

| Model | Test Accuracy |
|---|---|
| LogisticRegression | 67.6% |
| GaussianNB | 59.6% |
| KNeighborsClassifier | 69.2% |
| DecisionTreeClassifier | 69.0% |
| SVM | 69.0% |
| RandomForestClassifier | 66.6% |

Every model clustered around 66–69%, regardless of algorithm — a strong signal that the
*ceiling* is being hit, not a modeling failure.

## Root cause
The dataset had 6 columns: `Product_Category`, `Product_Age_Months`, `Warranty_Duration`,
`Damage_Type`, `Missing_Documents_Count`, `Label`.

Cross-tabulating each feature against `Label` revealed:

```
out_of_warranty = Product_Age_Months > Warranty_Duration
```
| out_of_warranty | Invalid | Manual Review | Valid |
|---|---|---|---|
| False | 0% | 50.0% | 50.0% |
| True | 100% | 0% | 0% |

`Damage_Type` and `Missing_Documents_Count` showed **no measurable relationship** to the
label at all (~33/33/33 split across every category/count).

**Theoretical ceiling**: `P(out_of_warranty) × 100% + P(within warranty) × 50%`
`= 0.333 × 1.0 + 0.667 × 0.5 = 66.7%` — matching the observed results almost exactly.

## Conclusion
This isn't a hyperparameter or algorithm problem. Half of the dataset's "Manual Review"
vs "Valid Claim" labels were assigned with **zero information** in the available columns —
mathematically equivalent to flipping a coin. No classifier, however good, can predict a
coin flip better than 50% on unseen data.

## Fix
Rebuilt the dataset generator so every label is driven by real signals the model can
learn from (see `README.md` for the full feature list and rule logic), which took the
achievable test accuracy from a hard 66.7% ceiling to **89.3%**.
