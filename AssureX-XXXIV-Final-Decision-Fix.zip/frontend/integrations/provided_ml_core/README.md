# AssureX Claim Engine — Python ML Core (Rebuilt)

## What was wrong with the original `model5.ipynb`

The uploaded model wasn't a bad choice of algorithm — the **dataset made 85% mathematically
impossible**. Diagnosis (see `reports/diagnosis.md` for the full trace):

- `claim_dataset5.csv` had only 6 columns.
- The label was fully explained by one rule: `Product_Age_Months > Warranty_Duration` →
  always "Invalid Claim" (~33% of rows).
- For the other ~67% of rows (still in warranty), "Valid Claim" vs "Manual Review" was an
  exact **50/50 coin flip**, uncorrelated with any of the remaining columns
  (`Damage_Type`, `Missing_Documents_Count`).
- Theoretical accuracy ceiling with those features: `0.333×1.0 + 0.667×0.5 = 66.7%` —
  which is exactly what LogisticRegression/KNN/DecisionTree/SVM/RandomForest all scored.

No amount of tuning fixes an unlearnable label. The fix had to happen at the dataset level.

## What changed

1. **Richer, SRS-aligned feature set** (`data/generate_dataset.py`): product category,
   age, warranty duration + extended warranty, purchase price, damage type, repair
   history + unauthorized-repair flag, serial-number match, missing-document count,
   fault-to-claim delay, contradiction flag, duplicate flag — 14 raw fields instead of 5.
2. **Rule-grounded label generation** instead of random assignment: warranty expiry,
   excluded-damage-type policy, repair-authorization rules, serial mismatch, missing
   docs, late reporting, and contradictions/duplicates all deterministically push a
   claim toward Invalid / Manual Review / Valid — with a **3% noise floor** so it's
   realistic rather than a lookup table.
3. **1,050 / 225 / 225 → scaled to 1,750 / 375 / 375** stratified train/val/test split
   (SRS's 70/15/15 ratio, on a larger 2,500-record dataset for lower variance).
4. **Feature engineering** (`model/train_model.py`): `Remaining_Warranty_Months`,
   `Out_Of_Warranty`, `Documents_Complete`, `High_Risk_Repair`, `Late_Report`, and an
   aggregate `Risk_Score` — these carry most of the model's predictive power (see
   `reports/feature_importance.png`).
5. **8 algorithms compared** (Logistic Regression, Naive Bayes, KNN, Decision Tree, SVM,
   Random Forest, Gradient Boosting, and a soft-voting ensemble) with 5-fold CV, plus a
   `GridSearchCV` pass around the winner.
6. **Warranty rule engine** (`rules/rule_engine.py` + `rules/warranty_policies.json`,
   6 category-specific policies) kept **independent** of the ML model and made
   **logically consistent** with the dataset's own generation rules — the two never
   contradict each other now (verified: 0 mismatches on a 40-claim spot check).
7. **Claim Summary Card generator** (`cards/generate_summary_card.py`) — produces the
   image handed to Google Teachable Machine, with ≥2 visual variations per claim,
   and deliberately excludes the Python model's prediction/confidence (per SRS Step 7).
8. **Decision engine** (`decision_engine.py`) — combines Python model confidence +
   Teachable Machine confidence (stubbed with a clearly-marked integration point for
   your exported TM model) + rule engine output into the final
   `Likely Valid / Likely Invalid / Manual Review Required` call, with full
   supporting/opposing factor explanations.

## Result

| Metric | Original notebook | Rebuilt pipeline |
|---|---|---|
| Test accuracy | 66–69% (ceiling, unfixable) | **89.3%** |
| Weighted F1 | ~0.65 | **0.893** |
| Features used | 5 | 19 (raw + engineered) |
| Algorithms compared | 6 | 8 + tuned ensemble |
| Business-rule engine | none | 6 policy files, fully independent |

Full metrics: `reports/final_metrics.json`, `reports/model_comparison.json`,
confusion matrix and feature importance plots in `reports/`.

## How to run

```bash
pip install -r requirements.txt
python data/generate_dataset.py      # builds claim_dataset.csv + train/val/test splits
python model/train_model.py          # trains, compares, and saves best_model.pkl
python decision_engine.py            # demo: full pipeline on one sample claim
```

## What's still a stub, and why

- **Google Teachable Machine** is a browser-only training tool (image classifier UI) —
  it can't be trained inside this sandbox. `decision_engine.py`'s
  `teachable_machine_predict()` is the single integration point: swap its body for
  inference against your exported `.h5`/`.tflite` model and the confidence-comparison,
  rule engine, and final-decision logic all work unchanged. Train it yourself on the
  Claim Summary Card images this pipeline generates (2 variations per training claim
  → 2,100+ images from the 1,050 training-split claims, matching the SRS minimum).
- **Web app / DB / auth / dashboards** (SRS sections i–l, xxxix–l) are out of scope
  here — this deliverable is the ML core the SRS asks for in sections 1.6.xvi–xxv and
  the Python Model / Dataset / Model-Comparison deliverables (2–6). Wire this into
  Flask/Django/FastAPI + your DB of choice per the SRS's interface requirements.

## Files

```
data/generate_dataset.py     # dataset generator (rule-grounded, not random)
data/claim_dataset.csv       # 2,500 records
data/train.csv / val.csv / test.csv
model/train_model.py         # training + comparison + evaluation
model/best_model.pkl, scaler.pkl, label_encoders.pkl, feature_columns.pkl, label_map.pkl
rules/warranty_policies.json # 6 category policies (SRS asks for ≥3)
rules/rule_engine.py         # warranty/contradiction/duplicate/serial checks
cards/generate_summary_card.py
decision_engine.py           # ties model + TM + rules into final decision
reports/                     # metrics, confusion matrix, feature importance, diagnosis
```
