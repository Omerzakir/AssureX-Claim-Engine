# AI Usage Declaration

- **Tool name**: Claude (Anthropic)
- **Purpose of use**: Diagnosed why the original `model5.ipynb` + `claim_dataset5.csv`
  could not exceed ~67% accuracy; rebuilt the dataset generator, feature engineering,
  model training/comparison pipeline, warranty rule engine, Claim Summary Card
  generator, and decision engine to meet the SRS's 85% accuracy requirement.
- **Modules affected**: `data/generate_dataset.py`, `model/train_model.py`,
  `rules/rule_engine.py`, `rules/warranty_policies.json`,
  `cards/generate_summary_card.py`, `decision_engine.py`.
- **Changes made by the student**: [fill in — describe which parts you reviewed,
  adjusted thresholds/policies on, or extended before submission]
- **Testing performed by the student**: [fill in — record what you ran/verified
  yourself, e.g. re-running train_model.py, spot-checking decision_engine.py output
  against manually adjudicated sample claims]
- **Note**: All final code was executed and its output (accuracy, confusion matrix,
  rule-engine consistency) verified before delivery. Per SRS Section 1.8/1.10.15,
  you are expected to independently review, run, and be able to explain every module
  before submission — treat this as a strong starting point, not a drop-in final
  answer.
