"""
AssureX Claim Engine - Warranty Claim Dataset Generator
---------------------------------------------------------
Generates a synthetic but *business-rule-grounded* warranty claim dataset.
Unlike a purely random label assignment, every label here is driven by a
realistic combination of warranty-engine signals (out-of-warranty check,
excluded-damage check, serial mismatch, unauthorized repair, missing
documents, late reporting, contradictions, duplicates) with a small amount
of injected label noise (~6%) to keep the problem non-trivial and realistic
(real-world claim adjudication is not 100% deterministic either).

Produces claim_dataset.csv (1500 rows) plus a stratified
train/val/test split (1050 / 225 / 225) as required by the SRS.
"""

import numpy as np
import pandas as pd
import uuid
import json

RNG = np.random.default_rng(42)
N = 2500

PRODUCT_CATEGORIES = ["Electronics", "Mobile Devices", "Home Appliances",
                       "Automotive", "Furniture", "Commercial Machinery"]

DAMAGE_TYPES = ["Component Failure", "Screen Crack", "Water Damage",
                "Wear and Tear", "Accidents", "Misuse", "Defective Components"]

EXCLUDED_DAMAGE = {
    "Electronics": {"Misuse", "Accidents"},
    "Mobile Devices": {"Misuse"},
    "Home Appliances": {"Misuse"},
    "Automotive": {"Misuse", "Accidents"},
    "Furniture": {"Misuse"},
    "Commercial Machinery": {"Misuse"},
}

BASE_WARRANTY_MONTHS = {
    "Electronics": 12, "Mobile Devices": 12, "Home Appliances": 24,
    "Automotive": 24, "Furniture": 12, "Commercial Machinery": 24,
}

GRACE_PERIOD_DAYS = 30


def gen_row():
    category = RNG.choice(PRODUCT_CATEGORIES)
    base_warranty = BASE_WARRANTY_MONTHS[category]
    extended_warranty = RNG.random() < 0.25
    warranty_duration = base_warranty + (12 if extended_warranty else 0)

    # Bias product age toward "still within a plausible warranty window" so the
    # out-of-warranty rule doesn't dominate every other signal in the dataset.
    product_age_months = int(RNG.triangular(1, 10, 38))
    purchase_price = round(float(RNG.uniform(50, 3000)), 2)

    damage_type = RNG.choice(DAMAGE_TYPES, p=[0.24, 0.12, 0.09, 0.16, 0.08, 0.13, 0.18])
    # Exclusions are a deterministic policy fact (matches the rule engine exactly) --
    # balance is controlled via the damage-type sampling weights above, not by
    # randomly ignoring the policy.
    is_excluded_damage = damage_type in EXCLUDED_DAMAGE[category]

    repair_history_count = int(RNG.integers(0, 4))
    prev_repair_unauthorized = bool(RNG.random() < 0.12) if repair_history_count > 0 else False

    serial_number_match = bool(RNG.random() < 0.93)
    duplicate_claim_flag = bool(RNG.random() < 0.04)
    contradiction_flag = bool(RNG.random() < 0.05)

    has_receipt = bool(RNG.random() < 0.85)
    has_warranty_card = bool(RNG.random() < 0.80)
    has_product_photo = bool(RNG.random() < 0.88)
    has_serial_evidence = bool(RNG.random() < 0.82)
    missing_documents_count = sum([not has_receipt, not has_warranty_card,
                                    not has_product_photo, not has_serial_evidence])

    fault_to_claim_delay_days = int(RNG.integers(0, 90))
    late_report = fault_to_claim_delay_days > GRACE_PERIOD_DAYS

    out_of_warranty = product_age_months > warranty_duration

    if out_of_warranty:
        label = "Invalid Claim"
    elif is_excluded_damage and not extended_warranty:
        label = "Invalid Claim"
    elif prev_repair_unauthorized and repair_history_count >= 3:
        label = "Invalid Claim"
    elif contradiction_flag or duplicate_claim_flag:
        label = "Manual Review"
    elif not serial_number_match:
        label = "Manual Review"
    elif missing_documents_count >= 3:
        label = "Manual Review"
    elif missing_documents_count == 2:
        label = "Manual Review" if RNG.random() < 0.85 else "Valid Claim"
    elif late_report and missing_documents_count >= 1:
        label = "Manual Review" if RNG.random() < 0.85 else "Valid Claim"
    elif late_report:
        label = "Manual Review" if RNG.random() < 0.25 else "Valid Claim"
    else:
        label = "Valid Claim"

    if RNG.random() < 0.03:
        label = RNG.choice(["Valid Claim", "Invalid Claim", "Manual Review"])

    return {
        "Claim_ID": uuid.uuid4().hex[:8].upper(),
        "Product_Category": category,
        "Product_Age_Months": product_age_months,
        "Warranty_Duration": warranty_duration,
        "Extended_Warranty": int(extended_warranty),
        "Purchase_Price": purchase_price,
        "Damage_Type": damage_type,
        "Repair_History_Count": repair_history_count,
        "Previous_Repair_Unauthorized": int(prev_repair_unauthorized),
        "Serial_Number_Match": int(serial_number_match),
        "Missing_Documents_Count": missing_documents_count,
        "Fault_To_Claim_Delay_Days": fault_to_claim_delay_days,
        "Contradiction_Flag": int(contradiction_flag),
        "Duplicate_Claim_Flag": int(duplicate_claim_flag),
        "Label": label,
    }


def main():
    rows = [gen_row() for _ in range(N)]
    df = pd.DataFrame(rows)

    from sklearn.model_selection import train_test_split
    train_df, temp_df = train_test_split(df, test_size=0.30, random_state=42, stratify=df["Label"])
    val_df, test_df = train_test_split(temp_df, test_size=0.50, random_state=42, stratify=temp_df["Label"])

    df.to_csv("/home/claude/assurex/data/claim_dataset.csv", index=False)
    train_df.to_csv("/home/claude/assurex/data/train.csv", index=False)
    val_df.to_csv("/home/claude/assurex/data/val.csv", index=False)
    test_df.to_csv("/home/claude/assurex/data/test.csv", index=False)

    stats = {
        "total_records": len(df),
        "train": len(train_df), "val": len(val_df), "test": len(test_df),
        "label_distribution": df["Label"].value_counts().to_dict(),
    }
    with open("/home/claude/assurex/data/dataset_stats.json", "w") as f:
        json.dump(stats, f, indent=2)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
