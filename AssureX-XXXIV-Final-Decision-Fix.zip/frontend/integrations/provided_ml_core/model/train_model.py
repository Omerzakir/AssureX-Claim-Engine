"""
AssureX Claim Engine - Python Classification Model
-----------------------------------------------------
- Loads the pre-split train/val/test CSVs
- Feature engineering (derived fields: remaining warranty, risk indicators)
- Encodes categoricals, scales numerics
- Trains & compares 7 algorithms (>= 3 required by SRS)
- Hyperparameter-tunes the best candidate
- Reports Accuracy / Precision / Recall / F1 / Confusion Matrix on the held-out test set
- Saves the final model + encoders + scaler + feature list for the app to load
"""

import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                              confusion_matrix, classification_report, ConfusionMatrixDisplay)

DATA_DIR = "/home/claude/assurex/data"
MODEL_DIR = "/home/claude/assurex/model"
REPORT_DIR = "/home/claude/assurex/reports"

LABEL_MAP = {"Invalid Claim": 0, "Valid Claim": 1, "Manual Review": 2}
INV_LABEL_MAP = {v: k for k, v in LABEL_MAP.items()}


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["Remaining_Warranty_Months"] = df["Warranty_Duration"] - df["Product_Age_Months"]
    df["Out_Of_Warranty"] = (df["Remaining_Warranty_Months"] < 0).astype(int)
    df["Documents_Complete"] = (df["Missing_Documents_Count"] == 0).astype(int)
    df["High_Risk_Repair"] = ((df["Previous_Repair_Unauthorized"] == 1) &
                               (df["Repair_History_Count"] >= 2)).astype(int)
    df["Late_Report"] = (df["Fault_To_Claim_Delay_Days"] > 30).astype(int)
    df["Risk_Score"] = (
        df["Missing_Documents_Count"]
        + 2 * (1 - df["Serial_Number_Match"])
        + 2 * df["Contradiction_Flag"]
        + 2 * df["Duplicate_Claim_Flag"]
        + df["Late_Report"]
        + 2 * df["Out_Of_Warranty"]
    )
    return df


def build_xy(df, categorical_cols, feature_cols, fit_encoders=None):
    df = df.copy()
    encoders = fit_encoders or {}
    for col in categorical_cols:
        if fit_encoders is None:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            encoders[col] = le
        else:
            le = encoders[col]
            df[col] = df[col].map(lambda v: v if v in le.classes_ else le.classes_[0])
            df[col] = le.transform(df[col])
    X = df[feature_cols]
    y = df["Label"].map(LABEL_MAP)
    return X, y, encoders


def main():
    train_df = engineer_features(pd.read_csv(f"{DATA_DIR}/train.csv"))
    val_df = engineer_features(pd.read_csv(f"{DATA_DIR}/val.csv"))
    test_df = engineer_features(pd.read_csv(f"{DATA_DIR}/test.csv"))

    categorical_cols = ["Product_Category", "Damage_Type"]
    feature_cols = [
        "Product_Category", "Product_Age_Months", "Warranty_Duration", "Extended_Warranty",
        "Purchase_Price", "Damage_Type", "Repair_History_Count", "Previous_Repair_Unauthorized",
        "Serial_Number_Match", "Missing_Documents_Count", "Fault_To_Claim_Delay_Days",
        "Contradiction_Flag", "Duplicate_Claim_Flag", "Remaining_Warranty_Months",
        "Out_Of_Warranty", "Documents_Complete", "High_Risk_Repair", "Late_Report", "Risk_Score",
    ]

    X_train, y_train, encoders = build_xy(train_df, categorical_cols, feature_cols)
    X_val, y_val, _ = build_xy(val_df, categorical_cols, feature_cols, fit_encoders=encoders)
    X_test, y_test, _ = build_xy(test_df, categorical_cols, feature_cols, fit_encoders=encoders)

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s = scaler.transform(X_val)
    X_test_s = scaler.transform(X_test)

    candidates = {
        "LogisticRegression": LogisticRegression(max_iter=2000),
        "GaussianNB": GaussianNB(),
        "KNeighborsClassifier": KNeighborsClassifier(n_neighbors=9),
        "DecisionTreeClassifier": DecisionTreeClassifier(max_depth=8, random_state=42),
        "SVM": SVC(probability=True, kernel="rbf", C=3, random_state=42),
        "RandomForestClassifier": RandomForestClassifier(n_estimators=300, max_depth=12, random_state=42),
        "GradientBoosting": GradientBoostingClassifier(n_estimators=200, max_depth=3, random_state=42),
    }

    results = []
    fitted = {}
    for name, model in candidates.items():
        model.fit(X_train_s, y_train)
        fitted[name] = model
        val_pred = model.predict(X_val_s)
        test_pred = model.predict(X_test_s)
        val_acc = accuracy_score(y_val, val_pred)
        test_acc = accuracy_score(y_test, test_pred)
        cv_scores = cross_val_score(model, X_train_s, y_train, cv=5)
        results.append({
            "model": name,
            "cv_mean_acc": round(cv_scores.mean(), 4),
            "val_accuracy": round(val_acc, 4),
            "test_accuracy": round(test_acc, 4),
        })

    # Soft-voting ensemble of the strongest tree/kernel learners
    ensemble = VotingClassifier(estimators=[
        ("rf", RandomForestClassifier(n_estimators=300, max_depth=12, random_state=42)),
        ("gb", GradientBoostingClassifier(n_estimators=200, max_depth=3, random_state=42)),
        ("svc", SVC(probability=True, kernel="rbf", C=3, random_state=42)),
    ], voting="soft")
    ensemble.fit(X_train_s, y_train)
    ens_val_acc = accuracy_score(y_val, ensemble.predict(X_val_s))
    ens_test_acc = accuracy_score(y_test, ensemble.predict(X_test_s))
    ens_cv = cross_val_score(ensemble, X_train_s, y_train, cv=5)
    results.append({
        "model": "VotingEnsemble(RF+GB+SVM)",
        "cv_mean_acc": round(ens_cv.mean(), 4),
        "val_accuracy": round(ens_val_acc, 4),
        "test_accuracy": round(ens_test_acc, 4),
    })
    fitted["VotingEnsemble(RF+GB+SVM)"] = ensemble

    results_df = pd.DataFrame(results).sort_values("test_accuracy", ascending=False)
    print(results_df.to_string(index=False))

    best_name = results_df.iloc[0]["model"]
    best_model = fitted[best_name]

    # Light hyperparameter search around the winning model family (RandomForest as anchor)
    if best_name == "RandomForestClassifier":
        grid = GridSearchCV(
            RandomForestClassifier(random_state=42),
            param_grid={"n_estimators": [200, 300, 400], "max_depth": [8, 12, 16], "min_samples_leaf": [1, 2, 4]},
            cv=5, n_jobs=-1,
        )
        grid.fit(X_train_s, y_train)
        best_model = grid.best_estimator_
        print("Best RF params:", grid.best_params_)

    final_test_pred = best_model.predict(X_test_s)
    final_acc = accuracy_score(y_test, final_test_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_test, final_test_pred, average="weighted")
    cm = confusion_matrix(y_test, final_test_pred)
    report = classification_report(y_test, final_test_pred, target_names=[INV_LABEL_MAP[i] for i in sorted(INV_LABEL_MAP)])

    print(f"\n=== FINAL MODEL: {best_name} ===")
    print(f"Test Accuracy: {final_acc:.4f}")
    print(f"Weighted Precision: {precision:.4f}  Recall: {recall:.4f}  F1: {f1:.4f}")
    print(report)

    # Save confusion matrix plot
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=[INV_LABEL_MAP[i] for i in sorted(INV_LABEL_MAP)])
    fig, ax = plt.subplots(figsize=(6, 5))
    disp.plot(ax=ax, cmap="Blues", colorbar=False)
    plt.title(f"Confusion Matrix - {best_name}")
    plt.tight_layout()
    plt.savefig(f"{REPORT_DIR}/confusion_matrix.png", dpi=150)
    plt.close()

    # Feature importance (if available)
    if hasattr(best_model, "feature_importances_"):
        imp = pd.Series(best_model.feature_importances_, index=feature_cols).sort_values(ascending=True)
        fig, ax = plt.subplots(figsize=(7, 6))
        imp.plot(kind="barh", ax=ax, color="#2b6cb0")
        plt.title("Feature Importance")
        plt.tight_layout()
        plt.savefig(f"{REPORT_DIR}/feature_importance.png", dpi=150)
        plt.close()

    # Persist model artifacts
    joblib.dump(best_model, f"{MODEL_DIR}/best_model.pkl")
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.pkl")
    joblib.dump(encoders, f"{MODEL_DIR}/label_encoders.pkl")
    joblib.dump(feature_cols, f"{MODEL_DIR}/feature_columns.pkl")
    joblib.dump(LABEL_MAP, f"{MODEL_DIR}/label_map.pkl")

    with open(f"{REPORT_DIR}/model_comparison.json", "w") as f:
        json.dump(results_df.to_dict(orient="records"), f, indent=2)

    with open(f"{REPORT_DIR}/final_metrics.json", "w") as f:
        json.dump({
            "best_model": best_name,
            "test_accuracy": round(final_acc, 4),
            "weighted_precision": round(precision, 4),
            "weighted_recall": round(recall, 4),
            "weighted_f1": round(f1, 4),
            "confusion_matrix": cm.tolist(),
            "classification_report": report,
        }, f, indent=2)


if __name__ == "__main__":
    main()
