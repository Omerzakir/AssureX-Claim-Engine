# AssureX — Requirement X: Complete Claim / Rule Validation Engine

Implemented on the Requirement IX Spark-compatible baseline.

## Scope

The claim validation engine is reusable at `js/claim-validation-engine.js` and is loaded by both the claim workflow and the Validation page.

It evaluates:

1. **Product / ownership checks**
   - Claim product ID must resolve to a registered product.
   - User claims must remain linked to the user's own product.
   - Product snapshot fields are compared with the current registered product.

2. **Serial / product identity checks**
   - Registered serial is compared with claim/product serial.
   - Invoice OCR serial is compared with registered serial.
   - Warranty-document OCR serial is compared with registered serial.
   - Missing registered serial is reported as a review warning.

3. **Warranty eligibility**
   - Uses the Requirement IX configurable warranty policy engine when available.
   - Checks purchase date, configured warranty duration, extended warranty, grace period, policy category/status and exclusions.
   - Reports `COVERED`, `NOT COVERED`, or `REVIEW` from the warranty engine without replacing the reviewer decision workflow.

4. **Missing-document / evidence checks**
   - Purchase invoice required.
   - Warranty evidence required.
   - Product photos required.
   - Repair-history evidence required when prior repair is declared.
   - Repair count/notes are checked when prior repair is declared.

5. **Contradiction checks**
   - Product snapshot vs registered product.
   - Invoice serial/model/product name vs registered product.
   - Warranty serial vs registered product.
   - Invoice purchase date vs registered purchase date.
   - Warranty duration vs registered warranty duration.
   - Repair declaration vs repair evidence.
   - Claim repair declaration/count vs persistent repair records.

6. **Duplicate-claim checks**
   - Compares claims from the same user and product.
   - Considers serial, fault category, description similarity and recency.
   - Strong matches are blocked before a new claim is saved.
   - Weaker matches are reported for review.

7. **Claim completeness**
   - Fault category required.
   - Fault description required.

## Validation result

The engine returns:

- `PASS` — no validation errors or warnings.
- `REVIEW` — warnings require human attention.
- `BLOCKED` — one or more validation errors exist.

It also returns a 0–100 data-quality score, severity counts, rule codes, findings, hard-block codes, warranty evaluation, engine name and engine version.

## Claim submission behavior

The claim wizard runs the engine after evidence has been stored and before the claim is committed.

Hard blocks currently stop submission for:

- missing/invalid product linkage
- product ownership mismatch
- serial mismatch
- strong duplicate claim

Other validation failures, such as warranty non-coverage or missing evidence that the wizard already requires, are recorded for review rather than silently changing the reviewer workflow.

A successful claim stores a `validation` object containing:

- `status`
- `score`
- `findingCount`
- `counts`
- `findings`
- `hardBlocks`
- `engine`
- `engineVersion`
- `checkedAt`

## Validation page

`validation.html` now uses the same engine and loads:

- claims
- registered products
- repair records

Users see their own data. Reviewers see the manual-review queue. Employees and admins can inspect the full operational set according to the existing RBAC rules.

The page supports selecting one claim or validating the complete visible claim set.

## Firestore / Spark compatibility

No Firebase Storage, Cloud Functions, Blaze-only feature, or Storage Rules are required.

The implementation continues to use the existing Firestore-only document store and existing RBAC rules.

## Files added / changed

- `js/claim-validation-engine.js` — new reusable validation engine.
- `claims.html` — validation engine loaded and run during submission; validation snapshot saved on the claim.
- `validation.html` — replaced the earlier limited validation logic with the shared engine.

## Testing performed

- JavaScript syntax check passed for the new validation engine.
- JavaScript syntax check passed for the updated inline scripts in `claims.html` and `validation.html`.
- Package is intended to be deployed using the same Firebase configuration and Firestore rules workflow as the previous phases.
