# AssureX completion status and secure deployment

This package preserves the existing frontend and introduces security fixes. It does **not** claim that all 50 functional requirements are production-complete. The two independently trained model files, real Firebase credentials/project, and live tests cannot be recreated from source code alone without the real labeled dataset and deployment environment. Do not substitute sample or invented ML metrics.

## Implemented in this revision
- A single effective role guard (`js/role-guard.js`); access lookup now fails closed if user profile is unavailable or disabled; `admin.html` is admin-only. `role-access.js` remains a legacy, unused module, retained to avoid breaking external consumers.
- FastAPI analyzes and reviews only with verified Firebase bearer ID tokens. The actor UID/role comes from the server-side users/{uid} document, not the request body.
- Reviews use a Firestore transaction that validates claim eligibility, stores the reviewer decision, creates append-only audit record and notifies claimant. A justification is required.
- Strict API CORS configuration via `ASSUREX_ALLOWED_ORIGINS`.
- The browser automatically supplies the current user's short-lived ID token to API calls.
- Removed fabricated verification successes from claim-to-ML request; unknown verification features force manual review instead of generating deceptive ML results.

## Remaining deployment requirements (cannot be completed from this ZIP alone)
1. Install actual fitted and evaluated Python model artifacts in `model_integration/models/python/` (`best_model.pkl`, `scaler.pkl`, `label_encoders.pkl`, `feature_columns.pkl`, `label_map.pkl`), using your own labeled warranty claim dataset and documented holdout evaluation.
2. Export a separately trained Google Teachable Machine image model into `model_integration/models/teachable_machine/` (`model.json`, `metadata.json`, `weights.bin`). Verify equal three-class taxonomy and evaluate both models on held-out matched claims.
3. Configure Firebase credentials **server-side** using `GOOGLE_APPLICATION_CREDENTIALS` or application default credentials, add Firebase Admin SDK dependencies, and deploy Firestore/Storage rules after security review. Do not bundle secret keys.
4. Deploy API behind HTTPS and set `ASSUREX_ALLOWED_ORIGINS` to exact trusted frontend origins. Run Uvicorn from the `frontend` directory: `uvicorn backend.app:app --host 127.0.0.1 --port 8000`.
5. Complete real end-to-end tests with customer, employee, reviewer, and admin Firebase accounts, real test documents, actual model artifacts, and applicable Firestore rules. Verify notification triggers, warranty alert scheduling, reporting coverage, data exports, monitoring, accessibility, and cross-browser behavior.
6. Train/calibrate models and implement validated feature extraction for the six verified numeric indicators before enabling automated model decisions. Missing inputs must not be treated as positive validations.

## Important behavior
Model-unavailable returns 503; unverified input returns 422; both leave the frontend's claim in the manual-review workflow. `/health` is unprotected for infrastructure monitoring; mutation endpoints require identity. No credentials included.
