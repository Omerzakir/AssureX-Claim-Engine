# AssureX Add Product — Firestore Schema

This form creates a document in the `products` collection with these exact fields:

brand
category
coverage_conditions
created_at
exclusions
extended_warranty_months
model_number
name
price
product_id
purchase_date
retailer
serial_number
service_center
user_id
warranty_months
warranty_provider

Example:
{
  brand: "Samsung",
  category: "Home Appliance",
  coverage_conditions: "",
  created_at: server timestamp,
  exclusions: "",
  extended_warranty_months: 0,
  model_number: "123456789",
  name: "Laptop",
  price: 95299,
  product_id: "PRD-55645",
  purchase_date: "2026-01-15",
  retailer: "Tech Zone",
  serial_number: "Test-Se-123",
  service_center: "Samsung Care Center",
  user_id: "USR-1001",
  warranty_months: 12,
  warranty_provider: "Samsung"
}

IMPORTANT:
Load the existing AssureX Firebase SDK/config before add-product.js.
The script expects the existing global `window.fbDb` and does not redeclare `db` or `fbAuth`.
