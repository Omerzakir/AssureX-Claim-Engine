INTEGRATION GUIDE — dashboard.html
==================================

1) Add the Firebase SDK + these files to dashboard.html.
   Place these <script> tags AFTER your other libraries
   and BEFORE dashboard_app.js:

   <!-- Firebase SDK (compat, v9) -->
   <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
   <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js"></script>

   <!-- Your Firebase layer (load in THIS order) -->
   <script src="firebase-config.js"></script>
   <script src="firebase-auth.js"></script>
   <script src="firebase-firestore.js"></script>

   Then keep your existing:
   <script src="dashboard_app.js"></script>

2) Fill in firebase-config.js with your real credentials
   (Firebase Console → Project settings → Your apps → Web).

3) Paste the contents of firestore.rules.txt into
   Firebase Console → Firestore Database → Rules → Publish.

4) Minimal usage inside dashboard_app.js (UI untouched):

   // Gate the dashboard on login
   AuthService.onAuthChanged(function (user, userDoc) {
     if (!user) { window.location.href = 'login.html'; return; }
     // ...existing dashboard init code...
   });

   // Load claims into your existing claim-workflow UI
   DbService.listenClaims(AuthService.getUid(), function (claims) {
     renderClaimsList(claims);   // your existing render function
   });

   // Create a claim from your existing form
   const claimId = await DbService.createClaim({
     productId: selectedProductId,
     title: claimTitle,
     description: claimDescription,
     amount: claimAmount
   });

   // Register an uploaded document's metadata
   await DbService.addDocument({
     claimId: claimId,
     filePath: uploadedFilePath,   // your existing path approach
     fileName: file.name,
     fileType: file.type,
     fileSize: file.size
   });

   // Model comparison UI
   const versions = await DbService.getModelVersions();
   const comparison = await DbService.compareModels(versions[0].id, versions[1].id);

   // Notifications
   DbService.listenNotifications(AuthService.getUid(), function (notifs) {
     updateNotificationBadge(notifs.filter(n => !n.read).length);
   });

NOTES
- Nothing in your UI/CSS changes — this layer only adds data.
- No Firebase Storage: documents stay as path+metadata, exactly as agreed.
- Firestore composite indexes: if a query errors with
  "requires an index", click the link in the browser console error —
  Firebase will generate the index for you automatically.
