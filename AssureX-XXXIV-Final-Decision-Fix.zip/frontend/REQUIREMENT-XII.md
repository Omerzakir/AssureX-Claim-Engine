# AssureX — Requirement XII
## Fault and Damage Evidence Upload

Implemented without replacing the existing landing page or application UI.

### Evidence supported
- Product photographs (multiple)
- Fault / damage evidence: JPG, PNG, MP4, WEBM, MOV
- Serial-number photograph: JPG/PNG
- Diagnostic report: PDF/JPG/PNG
- Purchase invoice and warranty document remain part of the claim evidence package
- Repair history document remains supported when the product was previously repaired

### Spark-compatible storage
Firebase Cloud Storage is not required. Files are stored as chunked Firestore binary data under:
`documents/{documentId}/chunks/{chunkId}`

Metadata is stored in `documents/{documentId}` and includes claim/product linkage, file type/size, SHA-256 hash, upload status and storage backend.

Limits:
- PDF/JPG/JPEG/PNG: 25 MB
- MP4/WEBM/MOV: 100 MB
- Firestore chunk size: 700 KiB

### Security / access
- Users upload and manage their own evidence.
- Reviewer/Employee/Admin can inspect evidence metadata and stored chunks according to Firestore rules.
- Admin has full document management access.
- SHA-256 duplicate detection prevents reusing the same file for the same user's stored evidence.

### Claim integration
Each uploaded evidence file is linked to the reserved Claim ID and Product ID. The claim stores document IDs grouped by evidence type, allowing later requirements such as document organization, missing-document detection, OCR, validation, duplicate detection and reporting to consume the same evidence records.

### Deployment note
After downloading/copying these project files, publish `firestore.rules.txt` as the project's Firestore Rules. Firebase Storage rules are not required for this Spark-compatible implementation.
