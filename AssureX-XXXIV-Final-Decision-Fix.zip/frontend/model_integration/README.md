# AssureX XVIII + XIX + XXI — Real Model Integration

This package integrates the **actual trained model artifacts** without retraining or fabricating predictions.

## Python classifier — XVIII/XIX
Place these exact artifacts in `models/python/`:
- `best_model.pkl`
- `scaler.pkl`
- `label_encoders.pkl`
- `feature_columns.pkl`
- `label_map.pkl`

The runtime requires `feature_columns.pkl` to exactly equal the 19-column XVII contract and requires `predict_proba()` so XIX confidence is the model's maximum class probability.

## Teachable Machine — XXI
Place the actual exported Teachable Machine image-model files in `models/teachable_machine/`:
- `model.json`
- `weights.bin`
- `metadata.json`

Expected labels, in order:
`Invalid Claim`, `Manual Review`, `Valid Claim`.
The runtime performs server-side TensorFlow inference at 224×224 and does not use browser-side TF.js prediction.

## Important
The model binaries themselves were not exposed by the current project-file interface during this implementation, so this package deliberately does **not** contain a replacement model. Once the uploaded binaries are available at these paths, the runtime loads them directly and fails closed if any artifact is missing or incompatible.


## XXII-XXIV — Comparison, confidence difference, consistency
The comparison layer consumes the `python_model` and `teachable_machine` outputs already produced by XVIII/XIX/XXI. It performs **no additional inference**.

- **XXII Prediction Comparison:** compares the two predicted class labels.
- **XXIII Confidence Score Comparison:** calculates the absolute confidence difference.
- **XXIV Consistency Status:** `Consistent`, `Inconsistent`, or `Uncertain`.

Comparison bands use the existing AssureX thresholds: 0.10 for Strong Match, 0.20 for Acceptable Match, and 0.35 for Weak Match. A differing prediction within 0.35 is `Model Disagreement`; a larger gap is `Uncertain Result`.

The adapter exposes `compare_model_outputs(python_result, teachable_machine_result)` so the existing model outputs flow directly into the comparison stage without another prediction layer.
