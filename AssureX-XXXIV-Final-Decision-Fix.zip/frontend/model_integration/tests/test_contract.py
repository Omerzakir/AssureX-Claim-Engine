import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'backend'))
from model.python_classifier import MODEL_COLUMNS, RAW_COLUMNS, ENGINEERED_COLUMNS

def test_19_feature_contract():
    assert len(RAW_COLUMNS)==13
    assert len(ENGINEERED_COLUMNS)==6
    assert len(MODEL_COLUMNS)==19

def test_supplied_trained_artifacts_bundled():
    base = Path(__file__).parents[1] / "models"
    assert all((base / "python" / name).is_file() for name in ("best_model.pkl", "scaler.pkl", "label_encoders.pkl", "feature_columns.pkl", "label_map.pkl"))
    assert all((base / "teachable_machine" / name).is_file() for name in ("model.json", "metadata.json", "weights.bin"))
