import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / 'backend'))
from model.comparison import compare_predictions
from model.analysis_result import attach_comparison


def model(label, confidence):
    return {'label': label, 'confidence': confidence}


def test_strong_match():
    r = compare_predictions(model('Valid Claim', .91), model('Valid Claim', .86))
    assert r['predictions_match'] is True
    assert r['comparison'] == 'Strong Match'
    assert r['consistency_status'] == 'Strong Match'
    assert r['confidence_difference'] == .05


def test_acceptable_match():
    r = compare_predictions(model('Valid Claim', .80), model('Valid Claim', .65))
    assert r['comparison'] == 'Acceptable Match'


def test_weak_match():
    r = compare_predictions(model('Valid Claim', .80), model('Valid Claim', .50), {'minimum_confidence': .40})
    assert r['comparison'] == 'Weak Match'


def test_disagreement():
    r = compare_predictions(model('Valid Claim', .80), model('Manual Review', .70))
    assert r['predictions_match'] is False
    assert r['comparison'] == 'Model Disagreement'
    assert r['consistency_status'] == 'Model Disagreement'


def test_low_confidence_is_uncertain_even_when_labels_match():
    r = compare_predictions(model('Valid Claim', .52), model('Valid Claim', .50))
    assert r['comparison'] == 'Uncertain Result'
    assert r['consistency_status'] == 'Uncertain Result'


def test_large_gap_is_disagreement_when_both_confident():
    r = compare_predictions(model('Valid Claim', .99), model('Valid Claim', .60))
    assert r['comparison'] == 'Model Disagreement'


def test_configurable_thresholds():
    r = compare_predictions(
        model('Valid Claim', .80), model('Valid Claim', .65),
        {'model_consistency': {'strong_match_max_difference': .20}}
    )
    assert r['comparison'] == 'Strong Match'


def test_attach_preserves_model_outputs_and_exposes_all_acceptance_fields():
    original = {
        'python_model': model('Invalid Claim', .77),
        'teachable_machine': model('Invalid Claim', .75),
    }
    py_before = original['python_model'].copy()
    tm_before = original['teachable_machine'].copy()
    out = attach_comparison(original)
    assert out['python_model'] == py_before
    assert out['teachable_machine'] == tm_before
    assert out['comparison']['comparison'] == 'Strong Match'
    assert out['comparison']['confidence_difference'] == .02
    assert out['consistency']['status'] == 'Strong Match'
