PLACE TRAINED PYTHON MODEL ARTIFACTS HERE.

Required files:
best_model.pkl
scaler.pkl
label_encoders.pkl
feature_columns.pkl
label_map.pkl

These files are intentionally excluded from the AssureX integration ZIP.
