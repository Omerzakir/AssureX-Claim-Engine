PLACE TRAINED GOOGLE TEACHABLE MACHINE ARTIFACTS HERE.

Required files:
model.json
metadata.json
weights.bin

The model metadata must expose exactly these three labels in this order:
Invalid Claim
Manual Review
Valid Claim

These files are intentionally excluded from the AssureX integration ZIP.
