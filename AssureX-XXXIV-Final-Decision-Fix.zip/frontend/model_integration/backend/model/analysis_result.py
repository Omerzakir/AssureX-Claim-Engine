"""Canonical result assembly for the AssureX model-analysis stages."""
from .comparison import compare_predictions


def assemble_model_comparison(python_model: dict, teachable_machine: dict, config: dict | None = None) -> dict:
    return compare_predictions(python_model, teachable_machine, config)


def attach_comparison(result: dict, config: dict | None = None) -> dict:
    """Attach XXII-XXIV fields to an existing pipeline result.

    Existing prediction objects are reused verbatim; this function does not
    call or re-run either classifier.
    """
    comparison = assemble_model_comparison(result["python_model"], result["teachable_machine"], config)
    result["comparison"] = comparison
    result["confidence_comparison"] = {
        "python_confidence": comparison["python_confidence"],
        "teachable_machine_confidence": comparison["teachable_machine_confidence"],
        "difference": comparison["confidence_difference"],
    }
    result["consistency"] = {
        "status": comparison["consistency_status"],
        "predictions_match": comparison["predictions_match"],
        "comparison": comparison["comparison"],
    }
    return result
