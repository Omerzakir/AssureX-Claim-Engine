"""Unified Python model runtime for AssureX XVIII/XIX."""
from pathlib import Path
import os
from .python_classifier import PythonClassifier

_DEFAULT = Path(os.environ.get('ASSUREX_PYTHON_MODEL_DIR', Path(__file__).resolve().parents[2] / 'models' / 'python'))
_classifier = None

def get_classifier():
    global _classifier
    if _classifier is None: _classifier = PythonClassifier(_DEFAULT)
    return _classifier

def classify_claim(claim: dict):
    return get_classifier().predict(claim)
