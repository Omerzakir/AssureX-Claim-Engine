"""Pipeline seam: real Python classifier + real TM classifier only."""
import os
from pathlib import Path
from model.runtime import classify_claim

def run_python(claim):
    return classify_claim(claim)

def tm_runtime_command():
    return os.environ.get('ASSUREX_TM_RUNTIME_COMMAND','node backend/teachable_machine/service.js')


def compare_model_outputs(python_result, teachable_machine_result):
    """XXII-XXIV: compare already-produced model outputs; never re-predict."""
    from model.analysis_result import attach_comparison
    return attach_comparison({
        "python_model": python_result,
        "teachable_machine": teachable_machine_result,
    })
