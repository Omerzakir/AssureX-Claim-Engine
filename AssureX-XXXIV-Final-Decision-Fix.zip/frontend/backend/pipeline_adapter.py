"""FastAPI-facing adapter: claim -> canonical preprocessing -> trained model."""
from pathlib import Path
import os
from .model.runtime import load_runtime


def run_python_model(claim, model_dir=None, contract=None):
    backend = Path(os.environ.get("ASSUREX_BACKEND_DIR", Path(__file__).resolve().parents[1]))
    root = Path(model_dir or os.environ.get("ASSUREX_MODEL_DIR", backend / "model"))
    runtime = load_runtime(root, contract=contract)
    return runtime.predict(claim)
