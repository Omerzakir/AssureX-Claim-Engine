"""AssureX Requirement XVI: canonical claim preprocessing.

The training model uses the engineered19 contract documented by AssureX:
13 source features + 6 engineered features, in the exact training order.
The raw13 contract remains available for compatibility, but runtime model
prediction must explicitly request a contract instead of silently guessing.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Mapping
import json
import numpy as np

RAW13 = [
    "Product_Category", "Product_Age_Months", "Warranty_Duration",
    "Extended_Warranty", "Purchase_Price", "Damage_Type",
    "Repair_History_Count", "Previous_Repair_Unauthorized",
    "Serial_Number_Match", "Missing_Documents_Count",
    "Fault_To_Claim_Delay_Days", "Contradiction_Flag", "Duplicate_Claim_Flag",
]
ENGINEERED6 = [
    "Remaining_Warranty_Months", "Out_Of_Warranty", "Documents_Complete",
    "High_Risk_Repair", "Late_Report", "Risk_Score",
]
ENGINEERED19 = RAW13 + ENGINEERED6
CATEGORICAL = ["Product_Category", "Damage_Type"]


def _text(v: Any) -> str:
    return "" if v is None else str(v).strip()


def _num(v: Any, default: float = 0.0) -> float:
    if v is None or v == "":
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _bool(v: Any) -> int:
    if isinstance(v, bool):
        return int(v)
    s = _text(v).lower()
    return int(s in {"1", "true", "yes", "y", "on", "match", "matched"})


def _date(v: Any):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = _text(v)[:10]
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def _first(d: Mapping[str, Any], *keys: str, default=None):
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
    return default


def canonicalize_claim(claim: Mapping[str, Any]) -> dict[str, Any]:
    """Map Firestore/API claim fields to the training dataset vocabulary."""
    c = dict(claim)
    product = c.get("product") if isinstance(c.get("product"), Mapping) else {}
    fault = c.get("fault") if isinstance(c.get("fault"), Mapping) else {}
    repair = c.get("repairHistory") if isinstance(c.get("repairHistory"), Mapping) else {}
    evidence = c.get("evidence") if isinstance(c.get("evidence"), Mapping) else {}

    purchase = c.get("purchase") if isinstance(c.get("purchase"), Mapping) else {}
    product_category = _first(c, "product_category", "productCategory", default=_first(product, "category", default=""))
    damage_type = _first(c, "damage_type", "damageType", "fault_category", "faultCategory", default=_first(fault, "category", default=""))
    purchase_date = _first(c, "purchase_date", "purchaseDate", default=_first(purchase, "date"))
    submission_date = _first(c, "submission_date", "submissionDate", default=c.get("createdAt"))
    fault_date = _first(c, "fault_date", "faultDate", default=c.get("faultDate"))

    repair_count = _first(c, "repair_history_count", "repairHistoryCount", default=_first(repair, "repairCount", default=0))
    unauthorized = _first(c, "previous_repair_unauthorized", "previousRepairUnauthorized", default=_first(repair, "unauthorized", default=False))

    warranty_duration = _first(c, "warranty_months", "warrantyMonths", default=_first(purchase, "warrantyMonths", default=0))
    extended = _first(c, "extended_warranty", "extendedWarranty", default=None)
    if extended is None:
        ext_months = _first(c, "extended_warranty_months", "extendedWarrantyMonths", default=_first(purchase, "extendedWarrantyMonths", default=0))
        extended = _num(ext_months) > 0

    receipt = _first(c, "receipt_available", "receiptAvailable", default=None)
    warranty_card = _first(c, "warranty_card_available", "warrantyCardAvailable", default=None)
    product_photo = _first(c, "product_image_available", "productImageAvailable", default=None)
    fault_evidence = _first(c, "fault_evidence_available", "faultEvidenceAvailable", default=None)
    missing_docs = _first(c, "missing_documents_count", "missingDocumentsCount", default=None)
    if missing_docs is None:
        supplied = [_bool(x) for x in (receipt, warranty_card, product_photo, fault_evidence) if x is not None]
        missing_docs = 4 - sum(supplied) if len(supplied) == 4 else 0

    serial_match = _first(c, "serial_number_match", "serialNumberMatch", default=None)
    if serial_match is None:
        entered = _first(c, "serial_number", "serialNumber", "repair_serial_number", "repairSerialNumber")
        recorded = _first(product, "serialNumber", "serial_number")
        serial_match = True if not entered or not recorded else entered == recorded

    contradiction = _bool(_first(c, "contradiction_flag", "contradictionFlag", default=False))
    duplicate = _bool(_first(c, "duplicate_claim_flag", "duplicateClaimFlag", default=False))

    fault_d = _date(fault_date); submit_d = _date(submission_date); purchase_d = _date(purchase_date)
    delay = _first(c, "fault_to_claim_delay_days", "faultToClaimDelayDays", default=None)
    if delay is None and fault_d and submit_d:
        delay = max(0, (submit_d - fault_d).days)

    age = _first(c, "product_age_months", "productAgeMonths", default=None)
    if age is None and purchase_d and submit_d:
        age = max(0, (submit_d - purchase_d).days / 30.4375)
    if age is None:
        age = 0

    return {
        "Product_Category": _text(product_category),
        "Product_Age_Months": _num(age),
        "Warranty_Duration": _num(warranty_duration),
        "Extended_Warranty": _bool(extended),
        "Purchase_Price": _num(_first(c, "purchase_price", "purchasePrice", default=_first(product, "price", "purchasePrice", default=_first(purchase, "amount", default=0)))),
        "Damage_Type": _text(damage_type),
        "Repair_History_Count": _num(repair_count),
        "Previous_Repair_Unauthorized": _bool(unauthorized),
        "Serial_Number_Match": _bool(serial_match),
        "Missing_Documents_Count": _num(missing_docs),
        "Fault_To_Claim_Delay_Days": _num(delay),
        "Contradiction_Flag": contradiction,
        "Duplicate_Claim_Flag": duplicate,
        "_purchase_date": purchase_d,
        "_submission_date": submit_d,
    }


def engineer_features(claim: Mapping[str, Any]) -> dict[str, Any]:
    r = canonicalize_claim(claim)
    duration = r["Warranty_Duration"] + (12 if r["Extended_Warranty"] else 0)
    age = r["Product_Age_Months"]
    remaining = duration - age
    out = int(remaining <= 0)
    complete = int(r["Missing_Documents_Count"] == 0)
    high_risk = int(r["Previous_Repair_Unauthorized"] and r["Repair_History_Count"] >= 3)
    late = int(r["Fault_To_Claim_Delay_Days"] > 30)
    risk = (
        out * 0.30 + (1 - r["Serial_Number_Match"]) * 0.20 +
        min(r["Missing_Documents_Count"] / 4.0, 1) * 0.15 +
        high_risk * 0.15 + late * 0.10 +
        r["Contradiction_Flag"] * 0.05 + r["Duplicate_Claim_Flag"] * 0.05
    )
    r.update({
        "Remaining_Warranty_Months": remaining,
        "Out_Of_Warranty": out,
        "Documents_Complete": complete,
        "High_Risk_Repair": high_risk,
        "Late_Report": late,
        "Risk_Score": risk,
    })
    return r


@dataclass
class Preprocessor:
    feature_contract: str
    label_encoders: dict[str, Any]
    scaler: Any
    feature_columns: list[str]

    def transform_one(self, claim: Mapping[str, Any]) -> np.ndarray:
        row = engineer_features(claim) if self.feature_contract == "engineered19" else canonicalize_claim(claim)
        cols = ENGINEERED19 if self.feature_contract == "engineered19" else RAW13
        if self.feature_columns and self.feature_columns != cols:
            raise ValueError(f"Feature contract mismatch: artifact columns {self.feature_columns} != {cols}")
        values = []
        for col in cols:
            value = row[col]
            if col in CATEGORICAL:
                enc = self.label_encoders.get(col)
                if enc is None:
                    raise ValueError(f"Missing fitted encoder for {col}")
                classes = list(enc.classes_)
                if value not in classes:
                    raise ValueError(f"Unknown category for {col}: {value!r}")
                value = int(enc.transform([value])[0])
            values.append(float(value))
        X = np.asarray([values], dtype=float)
        if self.scaler is not None:
            X = self.scaler.transform(X)
        return X


def metadata(pre: Preprocessor) -> dict[str, Any]:
    return {"feature_contract": pre.feature_contract, "feature_columns": pre.feature_columns,
            "categorical_features": CATEGORICAL, "version": "XVI.1"}
