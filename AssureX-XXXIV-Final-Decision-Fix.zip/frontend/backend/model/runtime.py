"""Artifact-backed Python model runtime for AssureX."""
from __future__ import annotations
import json
from pathlib import Path
import joblib
from .preprocessing import Preprocessor, ENGINEERED19, RAW13


def load_runtime(model_dir: str | Path, contract: str | None = None):
    root = Path(model_dir)
    required = ["best_model.pkl", "scaler.pkl", "label_encoders.pkl", "feature_columns.pkl", "label_map.pkl"]
    missing = [x for x in required if not (root / x).exists()]
    if missing:
        raise FileNotFoundError(f"Python model artifacts missing from {root}: {', '.join(missing)}")
    cols = joblib.load(root / "feature_columns.pkl")
    inferred = "engineered19" if list(cols) == ENGINEERED19 else "raw13" if list(cols) == RAW13 else None
    if inferred is None:
        raise ValueError(f"Unsupported feature_columns.pkl contract: {cols}")
    if contract and contract != inferred:
        raise ValueError(f"Requested {contract}, but fitted model artifacts declare {inferred}")
    enc = joblib.load(root / "label_encoders.pkl")
    scaler = joblib.load(root / "scaler.pkl")
    model = joblib.load(root / "best_model.pkl")
    label_map = joblib.load(root / "label_map.pkl")
    return PythonModelRuntime(model, Preprocessor(inferred, enc, scaler, list(cols)), label_map)


class PythonModelRuntime:
    def __init__(self, model, preprocessor, label_map):
        self.model = model
        self.preprocessor = preprocessor
        self.label_map = label_map

    def predict(self, claim):
        X = self.preprocessor.transform_one(claim)
        pred = int(self.model.predict(X)[0])
        probs = self.model.predict_proba(X)[0] if hasattr(self.model, "predict_proba") else None
        confidence = float(max(probs)) if probs is not None else None
        return {
            "label_index": pred,
            "label": self.label_map.get(pred, self.label_map.get(str(pred), str(pred))),
            "confidence": confidence,
            "probabilities": [float(x) for x in probs] if probs is not None else None,
            "feature_contract": self.preprocessor.feature_contract,
            "preprocessing_version": "XVI.1",
        }
