# AssureX Phase 2 — Structured OCR on Spark Plan

Phase 2 remains browser-based and now reads the original document bytes from the Spark-compatible Firestore chunk store instead of Firebase Cloud Storage.

## What was added
- `js/ocr-service.js` — reusable browser OCR + structured field extraction.
- `documents.html` — `OCR / Extract` action for stored documents.
- `js/storage-service.js` — reconstructs the stored file Blob from Firestore chunks.
- OCR data is saved under `documents/{documentId}.ocr`.

## Supported OCR sources
- PDF (up to first 10 pages for browser processing)
- JPG / JPEG
- PNG

Videos remain stored but are not sent to OCR.

## Stored OCR record
`documents/{documentId}.ocr` contains:
- `status`
- `rawText`
- `structured.invoiceNumber`
- `structured.purchaseDate`
- `structured.productName`
- `structured.brand`
- `structured.modelNumber`
- `structured.serialNumber`
- `structured.retailer`
- `structured.purchaseAmount`
- `structured.warrantyMonths`
- `confidence`
- `pages`
- `processedPages`
- `truncated`
- `engine`
- `engineVersion`
- `processedAt`

## Processing flow
Firestore chunks → reconstructed Blob → PDF rendering if needed → Tesseract OCR → raw text → field extraction → Firestore `documents.ocr`.

## Important
The extraction is heuristic and should not be treated as verified data yet. Requirement vii will add the user verification/edit screen so extracted fields can be corrected before they become trusted claim data.

## Test
1. Sign in as a User.
2. Open Documents.
3. Upload a real purchase invoice, warranty card, or receipt.
4. Click `OCR / Extract`.
5. Wait for OCR to finish.
6. Confirm the document shows OCR status and extracted fields.
7. Inspect the `documents` document and its `chunks` subcollection in Firestore.
8. Replace the document and confirm the previous OCR is cleared.
9. Upload an image/PDF with no readable text and confirm a clear OCR error is shown.
10. Try a video and confirm it remains stored but is not processed by OCR.
