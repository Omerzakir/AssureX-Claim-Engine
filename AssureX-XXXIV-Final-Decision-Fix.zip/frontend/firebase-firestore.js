/**
 * firebase-firestore.js
 * All Firestore CRUD for the app, mapped to your 8 collections.
 * Depends on: firebase-config.js, firebase-auth.js
 *
 * Documents now store Firebase Storage metadata plus the secure storage path/download URL.
 */

const DbService = {

    /* ============================ CLAIMS ============================ */

    /** Create a claim. Returns the new claim id. */
    createClaim: async function (claimData) {
        const uid = AuthService.getUid();
        const ref = await fbDb.collection(COLLECTIONS.CLAIMS).add({
            userId:      uid,
            status:      'pending',          // pending | under_review | approved | rejected
            createdAt:   FieldValue.serverTimestamp(),
            updatedAt:   FieldValue.serverTimestamp(),
            ...claimData
        });
        DbService.logAudit('claim_created', { claimId: ref.id });
        return ref.id;
    },

    /** Get claims. Pass a userId to scope to one user (null = all, for admins). */
    getClaims: async function (userId, limitCount) {
        let q = fbDb.collection(COLLECTIONS.CLAIMS);
        const uid = AuthService.getUid();
        if (userId) q = q.where('userId', '==', userId);
        else {
            let role = 'user';
            try { const profile = await fbDb.collection(COLLECTIONS.USERS).doc(uid).get(); role = profile.exists ? String(profile.data().role || 'user') : 'user'; } catch(e) {}
            if (role === 'user') q = q.where('userId', '==', uid);
            else if (role === 'reviewer') q = q.where('predictedDecision', '==', 'Manual Review');
        }
        const snap = await q.get();
        const rows = snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
        rows.sort(function(a,b){
            const av=a.createdAt&&a.createdAt.toMillis?a.createdAt.toMillis():a.createdAt&&a.createdAt.seconds?Number(a.createdAt.seconds)*1000:0;
            const bv=b.createdAt&&b.createdAt.toMillis?b.createdAt.toMillis():b.createdAt&&b.createdAt.seconds?Number(b.createdAt.seconds)*1000:0;
            return bv-av;
        });
        return limitCount ? rows.slice(0, limitCount) : rows;
    },

    /** Live listener version of getClaims (updates UI in real time). */
    listenClaims: function (userId, callback) {
        let q = fbDb.collection(COLLECTIONS.CLAIMS).orderBy('createdAt', 'desc');
        if (userId) q = q.where('userId', '==', userId);
        return q.onSnapshot(function (snap) {
            callback(snap.docs.map(function (d) { return { id: d.id, ...d.data() }; }));
        });
    },

    getClaim: async function (claimId) {
        const snap = await fbDb.collection(COLLECTIONS.CLAIMS).doc(claimId).get();
        return snap.exists ? { id: snap.id, ...snap.data() } : null;
    },

    updateClaim: async function (claimId, updates) {
        const current = await fbDb.collection(COLLECTIONS.CLAIMS).doc(claimId).get();
        const previous = current.exists ? current.data() : {};
        const nextStatus = updates.status || previous.status || 'pending';
        const historyEntry = {
            status: nextStatus,
            note: updates.statusNote || previous.statusNote || '',
            changedBy: AuthService.getUid(),
            source: updates.statusSource || 'web',
            changedAt: new Date().toISOString()
        };
        await fbDb.collection(COLLECTIONS.CLAIMS).doc(claimId).update({
            ...updates,
            statusHistory: FieldValue.arrayUnion(historyEntry),
            updatedAt: FieldValue.serverTimestamp()
        });
        DbService.logAudit('claim_updated', { claimId: claimId, fields: Object.keys(updates) });
    },

    updateClaimStatus: async function (claimId, status, note) {
        await DbService.updateClaim(claimId, { status: status, statusNote: note || '', statusSource: 'status_service' });
    },

    deleteClaim: async function (claimId) {
        await fbDb.collection(COLLECTIONS.CLAIMS).doc(claimId).delete();
        DbService.logAudit('claim_deleted', { claimId: claimId });
    },

    /* ============================ DOCUMENTS =========================
       Metadata-only storage: filePath, fileName, fileType, fileSize, etc. */

    /** Register a document's metadata (file itself stays where it is). */
    addDocument: async function (meta) {
        const uid = AuthService.getUid();
        const ref = await fbDb.collection(COLLECTIONS.DOCUMENTS).add({
            userId:     uid,
            uploadedAt: FieldValue.serverTimestamp(),
            ...meta     // { claimId?, filePath, fileName, fileType, fileSize, ... }
        });
        DbService.logAudit('document_added', { docId: ref.id, fileName: meta.fileName });
        return ref.id;
    },

    getDocuments: async function (userId, claimId) {
        let q = fbDb.collection(COLLECTIONS.DOCUMENTS);
        const uid = AuthService.getUid();
        let role = 'user';
        try { const profile = await fbDb.collection(COLLECTIONS.USERS).doc(uid).get(); role = profile.exists ? String(profile.data().role || 'user') : 'user'; } catch(e) {}
        if (userId) q = q.where('userId', '==', userId);
        else if (role === 'user') q = q.where('userId', '==', uid);
        if (claimId) q = q.where('claimId', '==', claimId);
        const snap = await q.get();
        return snap.docs.map(function (d) { return { id: d.id, ...d.data() }; }).sort(function(a,b){
            const av=a.uploadedAt&&a.uploadedAt.toMillis?a.uploadedAt.toMillis():0;
            const bv=b.uploadedAt&&b.uploadedAt.toMillis?b.uploadedAt.toMillis():0;
            return bv-av;
        });
    },

    updateDocument: async function (docId, updates) {
        await fbDb.collection(COLLECTIONS.DOCUMENTS).doc(docId).update(updates);
    },

    deleteDocument: async function (docId) {
        await fbDb.collection(COLLECTIONS.DOCUMENTS).doc(docId).delete();
        DbService.logAudit('document_deleted', { docId: docId });
    },

    /* ============================ PRODUCTS ============================ */


    createProduct: async function (productData) {
        const uid = AuthService.getUid();
        const ref = await fbDb.collection(COLLECTIONS.PRODUCTS).add({
            userId: uid,
            productId: "PROD-" + Date.now(),
            createdAt: FieldValue.serverTimestamp(),
            updatedAt: FieldValue.serverTimestamp(),
            ...productData
        });
        DbService.logAudit('product_created', { productId: ref.id });
        return ref.id;
    },

    updateProduct: async function (productId, updates) {
        await fbDb.collection(COLLECTIONS.PRODUCTS).doc(productId).update({
            ...updates,
            updatedAt: FieldValue.serverTimestamp()
        });
        DbService.logAudit('product_updated', { productId: productId });
    },

    deleteProduct: async function (productId) {
        await fbDb.collection(COLLECTIONS.PRODUCTS).doc(productId).delete();
        DbService.logAudit('product_deleted', { productId: productId });
    },

    getProducts: async function () {
        const uid = AuthService.getUid();
        let q = fbDb.collection(COLLECTIONS.PRODUCTS);
        try {
            const profile = await fbDb.collection(COLLECTIONS.USERS).doc(uid).get();
            const role = profile.exists ? String(profile.data().role || 'user') : 'user';
            if (role === 'user') q = q.where('user_id', '==', uid);
        } catch(e) { q = q.where('user_id', '==', uid); }
        const snap = await q.get();
        const rows = snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
        rows.sort(function(a,b){ return String(a.name||a.product_name||'').localeCompare(String(b.name||b.product_name||'')); });
        return rows;
    },

    getProduct: async function (productId) {
        const snap = await fbDb.collection(COLLECTIONS.PRODUCTS).doc(productId).get();
        return snap.exists ? { id: snap.id, ...snap.data() } : null;
    },

    /* ========================== MODEL_VERSIONS ========================
       Powers the AI/model comparison UI. */

    getModelVersions: async function () {
        const snap = await fbDb.collection(COLLECTIONS.MODEL_VERSIONS)
            .orderBy('version', 'desc').get();
        return snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
    },

    getModelVersion: async function (versionId) {
        const snap = await fbDb.collection(COLLECTIONS.MODEL_VERSIONS).doc(versionId).get();
        return snap.exists ? { id: snap.id, ...snap.data() } : null;
    },

    registerModelVersion: async function (data) {
        const uid = AuthService.getUid();
        const ref = await fbDb.collection(COLLECTIONS.MODEL_VERSIONS).add({
            ...data,
            createdBy: uid,
            createdAt: FieldValue.serverTimestamp()
        });
        DbService.logAudit('model_version_registered', { modelVersionId: ref.id, version: data.version || null, modelType: data.modelType || null });
        return ref.id;
    },

    resolveModelVersions: async function (claim) {
        const pythonVersion = claim && (claim.pythonModelVersion || claim.python_model_version || claim.modelVersion);
        const tmVersion = claim && (claim.teachableMachineVersion || claim.teachable_machine_version);
        const active = await DbService.getModelVersions();
        return {
            python: pythonVersion ? active.find(function (v) { return v.version === pythonVersion || v.id === pythonVersion; }) || null : active.find(function (v) { return v.modelType === 'python' && v.isActive; }) || null,
            teachableMachine: tmVersion ? active.find(function (v) { return v.version === tmVersion || v.id === tmVersion; }) || null : active.find(function (v) { return v.modelType === 'teachable_machine' && v.isActive; }) || null
        };
    },

    getActiveModel: async function () {
        const snap = await fbDb.collection(COLLECTIONS.MODEL_VERSIONS)
            .where('isActive', '==', true).limit(1).get();
        return snap.empty ? null : { id: snap.docs[0].id, ...snap.docs[0].data() };
    },

    /**
     * Compare two model versions for the AI comparison UI.
     * Returns { a, b, differences } where differences flags changed metrics.
     */
    compareModels: async function (versionA, versionB) {
        const [a, b] = await Promise.all([
            fbDb.collection(COLLECTIONS.MODEL_VERSIONS).doc(versionA).get(),
            fbDb.collection(COLLECTIONS.MODEL_VERSIONS).doc(versionB).get()
        ]);
        const dataA = a.exists ? { id: a.id, ...a.data() } : null;
        const dataB = b.exists ? { id: b.id, ...b.data() } : null;
        if (!dataA || !dataB) return null;

        const metrics = ['accuracy', 'precision', 'recall', 'f1Score'];
        const differences = {};
        metrics.forEach(function (m) {
            if (dataA[m] !== undefined && dataB[m] !== undefined) {
                differences[m] = {
                    a: dataA[m], b: dataB[m],
                    delta: (dataB[m] - dataA[m])
                };
            }
        });
        return { a: dataA, b: dataB, differences: differences };
    },

    /* ========================== NOTIFICATIONS ========================= */

    addNotification: async function (userId, notification) {
        await fbDb.collection(COLLECTIONS.NOTIFICATIONS).add({
            userId:    userId,
            read:      false,
            createdAt: FieldValue.serverTimestamp(),
            ...notification           // { title, body, type?, link? }
        });
    },

    /** Mark a single notification read. */
    markNotificationRead: async function (notifId) {
        await fbDb.collection(COLLECTIONS.NOTIFICATIONS).doc(notifId)
            .update({ read: true, readAt: FieldValue.serverTimestamp() });
    },

    /** Mark ALL of the current user's notifications read. */
    markAllNotificationsRead: async function () {
        const uid = AuthService.getUid();
        if (!uid) return;
        const snap = await fbDb.collection(COLLECTIONS.NOTIFICATIONS)
            .where('userId', '==', uid).where('read', '==', false).get();
        const batch = fbDb.batch();
        snap.docs.forEach(function (d) { batch.update(d.ref, { read: true }); });
        await batch.commit();
    },

    listenNotifications: function (userId, callback) {
        return fbDb.collection(COLLECTIONS.NOTIFICATIONS)
            .where('userId', '==', userId)
            .orderBy('createdAt', 'desc')
            .limit(50)
            .onSnapshot(function (snap) {
                callback(snap.docs.map(function (d) { return { id: d.id, ...d.data() }; }));
            });
    },

    /* ============================ AUDIT_LOGS ========================== */

    /** Write an audit_logs entry (fire-and-forget). */
    logAudit: function (action, details, options) {
        const uid = AuthService.getUid();
        if (!uid) return Promise.resolve(null);
        return fbDb.collection(COLLECTIONS.AUDIT_LOGS).add({
            userId: uid,
            action: String(action || 'UNKNOWN'),
            details: details || {},
            source: options && options.source || 'web',
            timestamp: FieldValue.serverTimestamp()
        }).catch(function (e) { console.warn('[Audit] failed:', e); return null; });
    },

    logError: function (error, context) {
        const uid = AuthService.getUid();
        const payload = {
            userId: uid,
            code: error && error.code || 'unknown_error',
            message: String(error && error.message || error || 'Unknown error').slice(0, 1000),
            context: context || {},
            page: window.location && window.location.pathname || '',
            timestamp: FieldValue.serverTimestamp()
        };
        return fbDb.collection(COLLECTIONS.ERROR_EVENTS).add(payload)
            .catch(function (e) { console.warn('[ErrorLog] failed:', e); return null; });
    },

    recordAnomaly: function (type, severity, details) {
        const uid = AuthService.getUid();
        return fbDb.collection(COLLECTIONS.ANOMALY_ALERTS).add({
            userId: uid,
            type: String(type || 'unknown'),
            severity: String(severity || 'medium'),
            details: details || {},
            acknowledged: false,
            createdAt: FieldValue.serverTimestamp()
        }).catch(function (e) { console.warn('[Monitoring] anomaly write failed:', e); return null; });
    },

    getAnomalyAlerts: async function (limitCount) {
        let q = fbDb.collection(COLLECTIONS.ANOMALY_ALERTS).orderBy('createdAt', 'desc');
        if (limitCount) q = q.limit(limitCount);
        const snap = await q.get();
        return snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
    },

    getAuditLogs: async function (limitCount) {
        let q = fbDb.collection(COLLECTIONS.AUDIT_LOGS).orderBy('timestamp', 'desc');
        if (limitCount) q = q.limit(limitCount);
        const snap = await q.get();
        return snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
    },

    /* ========================== SECURITY_EVENTS ======================= */

    logSecurityEvent: function (type, data) {
        fbDb.collection(COLLECTIONS.SECURITY_EVENTS).add({
            type:      type,
            uid:       AuthService.getUid(),
            userAgent: navigator.userAgent,
            data:      data || {},
            timestamp: FieldValue.serverTimestamp()
        }).catch(function (e) { console.warn('[Security] failed:', e); });
    },

    getSecurityEvents: async function (limitCount) {
        let q = fbDb.collection(COLLECTIONS.SECURITY_EVENTS).orderBy('timestamp', 'desc');
        if (limitCount) q = q.limit(limitCount);
        const snap = await q.get();
        return snap.docs.map(function (d) { return { id: d.id, ...d.data() }; });
    }
};
