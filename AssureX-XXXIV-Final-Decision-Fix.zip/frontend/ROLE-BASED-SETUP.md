# AssureX Role-Based Setup

## Roles
- user: own products/claims/warranties; cannot review or manage users
- reviewer: review claims predicted as Manual Review; can save decisions
- employee: operational read access; decision page is read-only; cannot create users
- admin: full access and user management

## Critical Firebase step
Publish `firestore.rules.txt` in Firebase Console > Firestore Database > Rules. Client-side filtering is not security; the deployed Firestore rules are authoritative.

## Existing test accounts
Open Firestore > `users` and inspect the document whose ID is the Firebase Authentication UID.
Set the testing customer account to:
```
role: user
```
Do not rely on the email address or browser session for the role.

The Admin page now lets an administrator change existing accounts between User, Reviewer and Employee.

## Product isolation
For a `user`, both the legacy `product.html` page and `products-single-page.html` query:
```
products.where('user_id', '==', firebase.auth().currentUser.uid)
```
A User never uses an unrestricted product query.

## Browser test
1. Sign out completely.
2. Sign in as User A.
3. Open Products and note the products shown.
4. Sign out.
5. Sign in as User B.
6. Open Products.
7. User B must not see User A's products.
8. If User B still sees them after the rules are published, inspect `users/{UserB_UID}.role`. If it is `reviewer`, `employee`, or `admin`, Firestore is correctly treating that account as staff and will permit broader reads.
