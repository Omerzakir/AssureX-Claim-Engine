# AssureX Requirement ix — Warranty Policy / Rule Engine

## Spark/free-plan implementation
This phase uses Firestore only. No Firebase Storage or Storage Rules are required.

## What was added
- `js/warranty-policy-engine.js` — reusable policy evaluator.
- `warranty-policies.html` — admin-only policy configuration page.
- `warranties.html` — now displays the policy-engine result for each product.
- `firestore.rules.txt` — adds `warranty_policies` permissions.
- `js/role-guard.js` — adds the admin-only `warrantyPolicies` route.

## Policy model
Collection: `warranty_policies/{policyId}`

Fields:
- `name`
- `active`
- `priority`
- `durationMonths`
- `graceDays`
- `eligibleCategories[]`
- `excludedCategories[]`
- `coveredStatuses[]`
- `exclusions[]`
- `notes`
- `createdAt`, `updatedAt`, `updatedBy`

## Evaluation
For each product the engine checks:
1. Purchase date exists.
2. A usable warranty duration exists.
3. Current date is within the coverage period, including configured grace days.
4. Product warranty status is allowed by the policy.
5. No configured exclusion is triggered.

The engine returns `COVERED`, `NOT COVERED`, or `REVIEW`, plus the policy name, expiry and failed checks/reasons.

## Duration behavior
The engine uses the larger of:
- product base warranty months + extended warranty months
- matching policy duration months

This preserves product-specific extended coverage while allowing policy rules to establish a minimum/standard duration.

## Default behavior
If no active Firestore policy exists, the engine uses a built-in 12-month standard policy. This allows the application to function immediately after deployment.

## Firebase setup
Publish the updated `firestore.rules.txt` in:
Firebase Console → Firestore Database → Rules

No Storage setup is needed.

## Testing
1. Sign in as Admin.
2. Open `warranty-policies.html` (linked from Warranties).
3. Create an active policy such as 12 months.
4. Open Warranties.
5. Confirm each product shows the policy-engine result.
6. Change duration/grace/category/exclusion settings and refresh.
7. Sign in as User and confirm policy-management controls are unavailable.
8. Confirm User still sees coverage results for their own products.
9. Confirm Reviewer/Employee can view warranty results but cannot manage policies.
