/* AssureX API bridge. UI is unchanged; this only adds the backend integration seam. */
(function(){
  const base = (window.ASSUREX_API_BASE || localStorage.getItem("ASSUREX_API_BASE") || "http://127.0.0.1:8000").replace(/\/$/,"");
  async function request(path, options){
    const user = window.fbAuth && window.fbAuth.currentUser;
    if (!user) throw new Error('Sign in to use AssureX analysis and review.');
    const token = await user.getIdToken();
    const opts = options || {};
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    let res;
    try { res = await fetch(base + path, Object.assign({}, opts, {signal:controller.signal, headers:Object.assign({}, opts.headers || {}, {"Content-Type":"application/json", "Authorization":"Bearer " + token})})); }
    finally { clearTimeout(timeout); }
    let data=null; try{data=await res.json();}catch(_){data={};}
    if(!res.ok){ const err=new Error((data.detail&&data.detail.message)||(typeof data.detail==='string'?data.detail:null)||"AssureX API request failed"); err.status=res.status; err.data=data; throw err; }
    return data;
  }
  window.AssureXAPI={
    base,
    health:()=>request("/health"),
    readiness:()=>request("/api/models/readiness"),
    analyzeClaim:(claim, extra)=>request("/api/claims/analyze",{method:"POST",body:JSON.stringify(Object.assign({claim:claim},extra||{}))}),
    reviewClaim:(payload)=>request("/api/claims/review",{method:"POST",body:JSON.stringify(payload)})
  };
})();
