/* Native entrance effects keep content visible if scripts or the network fail. */
(function () {
  'use strict';
  function boot() {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window) || !Element.prototype.animate) return;
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        observer.unobserve(entry.target);
        entry.target.animate([{ opacity: .65, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 360, easing: 'ease-out' });
      });
    });
    Array.from(document.querySelectorAll('.page-heading,.stat-card,.feature-card,.solution-card,.policy-card,.metric,.section-heading,.workflow-step,.vault-overview,.docs-layout > .card,.identity-card,.account-panels > *, .evaluation-card')).slice(0,40).forEach(function (el) { observer.observe(el); });
    window.addEventListener('pagehide', function () { observer.disconnect(); }, { once: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
