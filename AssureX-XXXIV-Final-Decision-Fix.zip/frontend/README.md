# AssureX Requirements XLVI-L — System Core & Operations

## XLVI — Data Storage
- Firestore remains the system-of-record on the Firebase Spark/free plan.
- Binary evidence continues to use `documents/{documentId}/chunks/{chunkId}` with parent metadata.
- Claim updates now append a `statusHistory` entry.
- Model version snapshots are retained on reviewed claims.

## XLVII — Audit Trail
- `audit_logs` records actor, action, details, source and timestamp.
- Audit records are append-only under Firestore rules.
- The authenticated UID must equal `audit_logs.userId`.
- Security events are also append-only.

## XLVIII — Model Version Tracking
- Existing `model_versions` collection is extended with registration/retrieval helpers.
- Claims can retain the Python and Teachable Machine version IDs/names used for review.
- `config/model_version_schema.json` defines the tracking contract.

## XLIX — Error Handling
- `DbService.logError()` records structured application errors in `error_events`.
- Global `error` and `unhandledrejection` handlers report runtime failures when a user is authenticated.
- Sensitive credentials are not collected by the error logger.

## L — Monitoring & Anomaly Alerts
- `anomaly_alerts` stores detected operational anomalies.
- Client-side model monitoring flags low confidence and model disagreement.
- The Python monitoring module detects repeated errors and claim-status distribution spikes without performing inference.
- Thresholds are intentionally operational alerts, not claim decisions.

No Cloud Functions, Firebase Cloud Storage, paid messaging service, or other Blaze-only dependency is introduced.
