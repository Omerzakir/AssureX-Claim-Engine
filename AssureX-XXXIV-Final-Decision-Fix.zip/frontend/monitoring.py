"""Compatibility wrapper for AssureX monitoring rules."""
from operations.monitoring import *
