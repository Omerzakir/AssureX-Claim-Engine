ASSUREX ROLE-BASED VERSION
===========================

Roles
-----
USER
- Own products only
- Can add/register products
- Can submit claims
- Can check own warranties
- Can view own dashboard/profile
- Cannot review or decide claims
- Cannot create users

REVIEWER
- Can inspect claims from any user when predictedDecision == "Manual Review"
- Can inspect related products/evidence needed for review
- Can approve, reject, or keep a claim in Manual Review
- Cannot create users
- Cannot change user roles

EMPLOYEE
- Can open operational pages, including User Management
- Can read users, products, claims and evidence
- Decision page is read-only
- Cannot save review/decision
- Cannot create users

ADMIN
- Full application access
- Can read/write operational data
- Can create User, Reviewer and Employee accounts from admin.html
- Can manage roles and user profiles

SECURITY
--------
Firestore rules are included in firestore.rules.txt. They are the authoritative security layer; UI guards only improve the user experience.

IMPORTANT: Deploy firestore.rules.txt to Firebase after copying the files.

Prediction queue
----------------
New claims created by claims.html are stored with:
  predictedDecision: "Manual Review"
  predictionStatus: "manual_review_pending"

This is a safe manual-review default because the current claim page does not contain a claim-level AI decision model. A future AI evaluation step can replace these fields with a supported prediction.

Integration
-----------
Copy the HTML files over the corresponding files in the existing AssureX project. Copy js/role-guard.js into your existing js/ folder. Keep your existing landing page, assets, CSS and other project files.

Firebase rules
--------------
Firebase Console -> Firestore Database -> Rules -> replace with firestore.rules.txt -> Publish.


SPARK-PLAN NOTE
This package does not use Firebase Cloud Storage. Documents are stored as chunked Firestore bytes under documents/{documentId}/chunks. Do not deploy Storage Rules; only publish firestore.rules.txt.
