# AssureX Phase 1 — Spark-plan Document Storage

This Spark-compatible version does **not** use Firebase Cloud Storage. Firebase currently requires the Blaze plan for Cloud Storage, so this implementation stores file bytes as chunked Firestore documents instead. No Storage bucket and no Storage Rules are required.

## What changed
- `js/storage-service.js` now stores file bytes in `documents/{documentId}/chunks/{chunkId}`.
- File metadata remains in `documents/{documentId}`.
- SHA-256 duplicate detection is preserved.
- Upload, view/download, replace and delete are preserved.
- `firestore.rules.txt` protects both metadata and file chunks.
- Firebase Storage SDK references were removed from the app.
- `storage.rules` is no longer needed and is intentionally unused.

## Spark-plan limits used by AssureX
- PDF/JPG/JPEG/PNG: 25 MB maximum.
- MP4/WEBM/MOV: 100 MB maximum.
- Chunk size: 700 KiB, kept below Firestore's 1 MiB document limit.
- Firestore's free tier currently includes 1 GiB stored data, 50,000 reads/day, 20,000 writes/day and 20,000 deletes/day for the free database.

Because each file becomes multiple Firestore writes, this approach is intended for development/prototyping and modest document volumes. Large video collections can consume the free quota faster.

## Firestore deployment
1. Open Firebase Console → Firestore Database → Rules.
2. Replace the existing rules with `firestore.rules.txt` from this package.
3. Publish.
4. **Do not** open Storage → Rules. This Spark version does not use Firebase Cloud Storage.

## Data model
`documents/{documentId}` stores metadata such as:
- `userId`
- `productId`
- `claimId`
- `documentType`
- `fileName`
- `fileType`
- `fileSize`
- `sha256`
- `storageBackend: "firestore"`
- `chunkSize`
- `chunkCount`
- `status`
- timestamps

The binary file is stored in:
`documents/{documentId}/chunks/{chunkIndex}`

Each chunk contains:
- `documentId`
- `userId`
- `index`
- `size`
- `data` (Firestore bytes)

## Role behavior
- User: upload/read/replace/delete own documents.
- Reviewer: read operational evidence only.
- Employee: read operational evidence only.
- Admin: read/upload/replace/delete all documents.

## Claim wizard
Claim evidence is stored in Firestore before the claim is committed. The claim records:
- `evidence.storageUploaded == true`
- `evidence.storageBackend == "firestore"`
- document IDs

## Test
1. Sign in as a User.
2. Open Claims and submit a claim with invoice, warranty and product image.
3. Confirm the claim contains document IDs and `storageBackend == "firestore"`.
4. Open Documents and confirm the files are listed.
5. Use View / Download; the app reconstructs the file from Firestore chunks.
6. Replace a document and confirm the metadata and chunks change.
7. Delete a document and confirm its metadata and chunks disappear.
8. Sign in as another User and confirm the first user's documents are not readable.
9. Sign in as Reviewer/Employee and confirm evidence is readable but not editable.
10. Sign in as Admin and confirm all document operations are available.
