# AssureX frontend upgrade

- Admin accounts list: select a user to lazy-load their products, warranties, documents, claims and repair histories from Firestore, with explicit errors and role-only access. No eager per-user fanout.
- Sidebar: six common pages display immediately; restricted entries appear only once role is verified. Evaluation now loads shared Firebase auth/role guard. Sidebar scrolls independently on desktop.
- Legacy app AuthService renamed internally to prevent JavaScript global redeclaration while shared Firebase auth remains authoritative for DbService.
- Analytics canvas constrained to responsive grid and page width. Profile card polished without changing field IDs or handlers.
- Mark-all-read notifications no longer requires a compound Firestore index; individual read failures are surfaced.
- Static CSS is local, and chart data loads separately from main shell.

Important: Actual speed and live Firestore security depend on hosted setup, Firebase rules, records, network and deployed indexes. Admin record explorer expects `userId` ownership on the named collections. Verify actual collection name `repair_history` against your deployment and amend if needed. Open the site using localhost, not file://.

- Shared role guard completes missing permitted navigation links on all sidebar pages; only verified roles can see protected sections.
- Admin user drilldown additionally exposes stored profile fields, with safe text rendering; repair collection corrected to `repair_records`.
- Admin aggregate metrics deferred until after accounts render; fixes to legacy auth initialization global guard.
