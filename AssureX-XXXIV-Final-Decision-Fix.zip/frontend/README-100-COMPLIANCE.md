# AssureX 100% Compliance Integration Package

This package preserves the existing AssureX UI and adds the missing end-to-end integration layer for the requirements specification.

## What is included

- FastAPI claim-analysis orchestration: `POST /api/claims/analyze`
- Model readiness endpoint: `GET /api/models/readiness`
- Health endpoint: `GET /health`
- Manual-review endpoint: `POST /api/claims/review`
- Canonical decisions: `Likely Valid`, `Likely Invalid`, `Manual Review Required`
- Neutral Claim Summary Card generation with no prediction/decision on the card
- Existing warranty policy/rule engine integration
- Serial-number verification
- Contradiction detection
- Missing-document detection
- Duplicate claim detection
- Duplicate-document SHA-256 detection
- Python/TM prediction comparison and confidence difference
- Decision explanation and claim-preparation output
- Model-version fields in analysis results
- Frontend bridge from `claims.html` to the FastAPI pipeline
- Safe fallback to Manual Review when model artifacts are intentionally absent
- `requirements.txt`, `.env.example`, and `start-backend.bat`

## Intentionally excluded

Per request, the trained ML artifacts are NOT included:

### Python model

Place these in:

`model_integration/models/python/`

- `best_model.pkl`
- `scaler.pkl`
- `label_encoders.pkl`
- `feature_columns.pkl`
- `label_map.pkl`

### Teachable Machine

Place these in:

`model_integration/models/teachable_machine/`

- `model.json`
- `metadata.json`
- `weights.bin`

The application checks for all required files and refuses to fabricate predictions when they are absent.

## Run

1. Open a terminal in the `frontend` folder.
2. Install backend dependencies:

```bash
pip install -r backend/requirements.txt
```

3. Start the API:

```bash
start-backend.bat
```

4. Serve the existing frontend with a local HTTP server (do not use `file://` for Firebase modules).

5. When the trained artifacts are installed, the existing claim submission page automatically calls `/api/claims/analyze`.

## Compliance note

The package implements the non-model requirements and the complete model integration seam. Actual classification accuracy and live model inference cannot be claimed until the trained Python and Teachable Machine artifacts are supplied, because those artifacts were intentionally excluded.
