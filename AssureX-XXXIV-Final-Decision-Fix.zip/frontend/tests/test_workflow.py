from backend.decision.workflow import *

def base():
    return ({"label":"Valid Claim","confidence":0.90},{"label":"Valid Claim","confidence":0.88},{"comparison":"Strong Match","consistency_status":"Consistent","confidence_difference":0.02},{"blocked":False,"manual_review_flags":[]},{"blocked":False,"manual_review_flags":[]})

def test_summary_excludes_decision():
    s=generate_claim_summary({"product":{"name":"Phone","serialNumber":"SN1"},"fault":{"category":"Screen Crack"},"evidence":{"documentIds":["d1"]}})
    assert s["excludes_predictions"] and s["excludes_decision"] and "Valid Claim" not in s["text"]

def test_preparation():
    p=prepare_claim({}, {"missing_documents":[]}, {"serial_verification":{"status":"MATCH"}})
    assert p["ready"] and p["checklist"]["serial_verified"]

def test_approve():
    assert decide_claim(*base())["decision"] == "Likely Valid"

def test_block_reject():
    a=list(base()); a[3]={"blocked":True,"hard_block_reasons":["WARRANTY_EXPIRED"]}
    assert decide_claim(*a)["decision"] == "Likely Invalid"

def test_manual_on_disagreement():
    a=list(base()); a[2]={"comparison":"Model Disagreement","consistency_status":"Inconsistent"}
    assert decide_claim(*a)["decision"] == "Manual Review Required"

def test_explanation():
    d=decide_claim(*base()); e=explain_decision(d,base()[3],base()[4],base()[2]); assert e["decision"]=="Likely Valid" and e["reasons"]

def test_review_and_override():
    r=create_review_record("AXC-1","u1","Approve","checked evidence")
    o=apply_review_override({"decision":"Manual Review"},r,"reviewer")
    assert o["finalDecision"]=="Approve" and o["originalDecision"]=="Manual Review"

def test_override_rejects_user():
    r=create_review_record("AXC-1","u1","Reject")
    try: apply_review_override({"decision":"Approve"},r,"user")
    except PermissionError: return
    assert False


def _models(py_label="Valid Claim", py_conf=0.90, tm_label="Valid Claim", tm_conf=0.88, status="Strong Match"):
    return ({"label": py_label, "confidence": py_conf}, {"label": tm_label, "confidence": tm_conf},
            {"comparison": status, "consistency_status": status, "classes_match": py_label == tm_label,
             "confidence_difference": round(abs(py_conf - tm_conf), 4), "minimum_confidence": 0.55})

def _rules(**kwargs):
    base = {"blocked": False, "rules_failed": [], "manual_review_flags": [], "missing_documents": [],
            "contradictions": [], "duplicate_claim": {"is_duplicate": False},
            "duplicate_document": {"is_duplicate": False}}
    base.update(kwargs)
    return base

def test_xxxiv_likely_valid_requires_both_models_and_confidence():
    py, tm, cmp = _models()
    assert decide_claim(py, tm, cmp, _rules(), _rules())["decision"] == "Likely Valid"

def test_xxxiv_likely_invalid_when_both_models_agree_invalid():
    py, tm, cmp = _models("Invalid Claim", .91, "Invalid Claim", .89)
    assert decide_claim(py, tm, cmp, _rules(), _rules())["decision"] == "Likely Invalid"

def test_xxxiv_model_disagreement_routes_manual_review():
    py, tm, cmp = _models("Valid Claim", .91, "Invalid Claim", .90, "Model Disagreement")
    assert decide_claim(py, tm, cmp, _rules(), _rules())["decision"] == "Manual Review Required"

def test_xxxiv_low_confidence_routes_manual_review():
    py, tm, cmp = _models("Valid Claim", .54, "Valid Claim", .53, "Uncertain Result")
    assert decide_claim(py, tm, cmp, _rules(), _rules())["decision"] == "Manual Review Required"

def test_xxxiv_missing_documents_routes_manual_review():
    py, tm, cmp = _models()
    rules = _rules(missing_documents=["warranty_document"])
    assert decide_claim(py, tm, cmp, rules, _rules())["decision"] == "Manual Review Required"

def test_xxxiv_contradiction_routes_manual_review():
    py, tm, cmp = _models()
    rules = _rules(contradictions=["claim_before_purchase"])
    assert decide_claim(py, tm, cmp, rules, _rules())["decision"] == "Manual Review Required"

def test_xxxiv_duplicate_document_routes_manual_review():
    py, tm, cmp = _models()
    rules = _rules(duplicate_document={"is_duplicate": True})
    assert decide_claim(py, tm, cmp, rules, _rules())["decision"] == "Manual Review Required"

def test_xxxiv_blocking_rule_produces_likely_invalid():
    py, tm, cmp = _models()
    rules = _rules(blocked=True, rules_failed=["WARRANTY_EXPIRED"])
    result = decide_claim(py, tm, cmp, rules, _rules())
    assert result["decision"] == "Likely Invalid" and result["automatic"] is True

def test_xxxiv_evidence_is_complete_and_auditable():
    py, tm, cmp = _models()
    result = decide_claim(py, tm, cmp, _rules(), _rules())
    e = result["decision_evidence"]
    assert e["python_prediction"] == "Valid Claim"
    assert e["teachable_machine_prediction"] == "Valid Claim"
    assert e["confidence_difference"] == 0.02
    assert e["predictions_match"] is True
