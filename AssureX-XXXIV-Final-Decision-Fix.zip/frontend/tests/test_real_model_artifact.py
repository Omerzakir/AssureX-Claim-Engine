"""Smoke-check the actual user-supplied sklearn model using one held-out data row."""
import csv
from pathlib import Path
from model_integration.backend.model.python_classifier import PythonClassifier

ROOT=Path(__file__).resolve().parents[1]
def test_trained_python_model_predicts_all_three_scores():
    model=PythonClassifier(ROOT/'model_integration/models/python')
    with (ROOT/'integrations/provided_ml_core/data/test.csv').open(newline='') as file:
        row=next(csv.DictReader(file))
    result=model.predict(row)
    assert result['label'] in {'Valid Claim','Invalid Claim','Manual Review'}
    assert set(result['probabilities'])=={'Valid Claim','Invalid Claim','Manual Review'}
    assert abs(sum(result['probabilities'].values())-1)<1e-6
