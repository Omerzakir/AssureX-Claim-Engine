import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from common_dataset.schema import *

def test_contract_is_exact():
    assert len(RAW_COLUMNS)==13
    assert len(ENGINEERED_COLUMNS)==6
    assert len(MODEL_COLUMNS)==19

def test_valid_record():
    row={c:0 for c in RAW_COLUMNS}; row.update(Product_Category="Electronics",Damage_Type="Component Failure",Classification="Valid Claim")
    assert validate_record(row)==[]

def test_reject_unknown_category():
    row={c:0 for c in RAW_COLUMNS}; row.update(Product_Category="Unknown",Damage_Type="Component Failure",Classification="Valid Claim")
    assert "invalid Product_Category" in validate_record(row)
