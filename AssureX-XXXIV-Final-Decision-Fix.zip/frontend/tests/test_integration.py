from backend.warranty.integration import attach_fraud_checks

def test_attaches_without_replacing_warranty_result():
    base={'engine_version':'26.0.0','valid':True,'blocked':False,'requires_manual_review':False}
    claim={'serial_number':'BAD','documents':{}}
    product={'serial_number':'GOOD','purchase_date':'2025-01-01'}
    out=attach_fraud_checks(base,claim,product,{'serial_number':'BAD'})
    assert out['engine_version']=='26.0.0'
    assert out['valid'] is True
    assert out['requires_manual_review'] is True
    assert out['serial_verification']['status']=='MISMATCH'
