import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))
from backend.model.preprocessing import canonicalize_claim, engineer_features, RAW13, ENGINEERED19

def test_firestone_claim_maps_to_training_contract():
    c = {"product":{"category":"Electronics","price":500,"serialNumber":"SN1"},
         "purchase":{"date":"2026-01-01","warrantyMonths":12},
         "fault":{"category":"Screen Crack"}, "repairHistory":{"repairCount":1},
         "serialNumber":"SN1", "receipt_available":True,"warranty_card_available":True,
         "product_image_available":True,"fault_evidence_available":True,
         "fault_date":"2026-06-01","submission_date":"2026-06-10"}
    r=canonicalize_claim(c)
    assert list(k for k in RAW13 if k in r)==RAW13
    e=engineer_features(c)
    assert list(e[k] for k in ENGINEERED19 if k in e)==[e[k] for k in ENGINEERED19]
    assert e["Fault_To_Claim_Delay_Days"]==9
    assert e["Documents_Complete"]==1

def test_unknown_category_is_detected_by_runtime_contract():
    class E:
        classes_ = ["Electronics", "Mobile Devices"]
        def transform(self,x): return [0]
    class S:
        def transform(self,x): return x
    from backend.model.preprocessing import Preprocessor
    p=Preprocessor("engineered19", {"Product_Category":E(), "Damage_Type":E()}, S(), ENGINEERED19)
    try: p.transform_one({"product":{"category":"Unknown"}})
    except ValueError as e: assert "Unknown category" in str(e)
    else: raise AssertionError("unknown category was not rejected")
