from datetime import date
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
from warranty import PolicyStore, validate_warranty

CFG=Path(__file__).resolve().parents[1]/'config'/'warranty_policies.json'

def base():
    return {'purchase_date':'2026-01-01','fault_date':'2026-06-01','claim_submission_date':'2026-06-05','damage_type':'Component Failure','serial_number_match':True,'missing_documents_count':0,'repair_history_count':0}

def test_active_covered_claim():
    r=validate_warranty(base(),PolicyStore(CFG).get('standard-manufacturer'),today=date(2026,9,27))
    assert r['valid'] and not r['blocked'] and not r['requires_manual_review']

def test_expired_claim_blocks():
    c=base(); c['purchase_date']='2024-01-01'
    r=validate_warranty(c,PolicyStore(CFG).get('standard-manufacturer'),today=date(2026,9,27))
    assert r['blocked'] and 'WARRANTY_EXPIRED' in r['rules_failed']

def test_excluded_damage_blocks():
    c=base(); c['damage_type']='Water Damage'
    r=validate_warranty(c,PolicyStore(CFG).get('standard-manufacturer'),today=date(2026,9,27))
    assert r['blocked'] and 'EXCLUDED_DAMAGE' in r['rules_failed']

def test_serial_missing_and_duplicate_require_review():
    c=base(); c['serial_number_match']=False; c['missing_documents_count']=2; c['duplicate_claim_flag']=True
    r=validate_warranty(c,PolicyStore(CFG).get('standard-manufacturer'),today=date(2026,9,27))
    assert r['requires_manual_review'] and not r['blocked']
    assert {'SERIAL_MISMATCH','MISSING_DOCUMENTS','DUPLICATE'} <= set(r['manual_review_flags'])

def test_policy_is_configurable():
    store=PolicyStore(CFG)
    p=store.get('extended-24')
    p.active=True; p.standard_months=18; p.grace_period_days=5; p.excluded_faults=['Misuse']
    c=base(); c['purchase_date']='2025-04-01'; c['damage_type']='Component Failure'
    r=validate_warranty(c,p,today=date(2026,9,27))
    assert r['effective_warranty_months']==18
    assert r['valid']
