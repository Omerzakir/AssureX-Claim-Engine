from backend.fraud.detection import *

PRODUCT={'serial_number':'SN-001','purchase_date':'2025-01-10'}

def test_serial_match_and_mismatch():
    ok=verify_serial_number({'serial_number':'SN001' }, PRODUCT, {'serial_number':'SN-001'})
    assert ok['match'] is True
    bad=verify_serial_number({'serial_number':'SN999'}, PRODUCT, {'serial_number':'SN-001'})
    assert bad['match'] is False and bad['status']=='MISMATCH'

def test_contradictions():
    r=detect_contradictions({'fault_date':'2025-01-01','submission_date':'2025-01-20'}, PRODUCT)
    assert r['detected'] is True
    assert any(x['code']=='FAULT_BEFORE_PURCHASE' for x in r['findings'])

def test_missing_documents_and_repair():
    r=detect_missing_documents({'previously_repaired':'yes','documents':{'purchase_invoice':{'id':'1'}}})
    assert set(r['missing']) >= {'warranty_document','product_photo','fault_evidence','repair_history'}

def test_duplicate_claim():
    c={'product_id':'P1','serial_number':'SN1','damage_type':'Screen Crack','fault_date':'2026-01-01'}
    r=detect_duplicate_claim(c,[dict(c,claim_id='AXC-1')])
    assert r['duplicate'] is True and r['matches']==['AXC-1']

def test_duplicate_document_hash():
    r=detect_duplicate_document({'id':'new','sha256':'abc'},[{'id':'old','sha256':'ABC'}])
    assert r['duplicate'] is True and r['matches']==['old']

def test_combined_output():
    c={'serial_number':'BAD','documents':{},'fault_date':'2024-01-01','submission_date':'2025-01-01','product_id':'P1','damage_type':'Screen Crack'}
    r=run_fraud_checks(c,PRODUCT,{'serial_number':'BAD'},existing_claims=[dict(c,claim_id='old')],document={'id':'new','sha256':'x'},existing_documents=[{'id':'old-doc','sha256':'x'}])
    assert r['requires_manual_review'] is True
    assert any(f['code']=='DUPLICATE_CLAIM' for f in r['findings'])
    assert any(f['code']=='DUPLICATE_DOCUMENT' for f in r['findings'])
