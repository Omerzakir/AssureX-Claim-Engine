# AssureX: integrated user-supplied models and FastAPI

This package is based on the latest AssureX frontend, with its UI kept intact. The Python ML model (five fitted `.pkl` files) and the exported Teachable Machine model (`model.json`, `metadata.json`, `weights.bin`) have been installed in `model_integration/models/`. Supplied training data, source ML core, and the supplied separate FastAPI reference implementation are preserved in `integrations/`. See `integrations/INTEGRATION-MANIFEST.json` for hashes.

## Run the secured application

1. Create a Python virtual environment, install `backend/requirements.txt`.
2. Install Node.js 20+ and run `npm install` inside `model_integration/backend/teachable_machine`. Native TensorFlow.js (`@tensorflow/tfjs-node`) must load successfully on your deployment OS.
3. Configure Firebase Admin credentials using `GOOGLE_APPLICATION_CREDENTIALS` (do not commit keys). Set `ASSUREX_ALLOWED_ORIGINS` to the actual served frontend origin(s). Configure your frontend `firebase-config.js` with your existing authorized Firebase project.
4. From the `frontend/` folder start `python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000`; for local frontend use e.g. `python -m http.server 5500`. Do not open HTML as `file://`.
5. The frontend API bridge is `js/assurex-api.js`, using the signed-in user's Firebase ID token; `claims.html` calls `/api/claims/analyze`. Reviewers use `/api/claims/review`. Confirm `/api/models/readiness`, then submit a claim with verified required features.

## Important limitations / operational checks

- No Firebase Admin credentials were provided; real Firebase login, Firestore writes, review and notification delivery require deployment and live role-based testing.
- The local environment does not have `@tensorflow/tfjs-node` installed; exported TM files are bundled, but actual dual-model runtime inference must be verified after npm installation. Python saved-model smoke test passes.
- Claim analysis deliberately fails closed with a clear 422 when verified fraud/document inputs are unavailable; absent values must not be silently turned into negative fraud flags. The claim is queued for manual review. For full automatic analysis, connect verified field extraction to claim submission and use database-backed duplicate searches; do not treat client-supplied search lists as security evidence.
- The provided independent FastAPI backend is included for comparison, *not* launched as an unauthenticated second service. The existing `backend.app:app` maintains Firebase token verification for sensitive endpoints.
- No live benchmark, production security audit, or entire 50-point acceptance test was possible without deployed services. Do not represent them as passed.
