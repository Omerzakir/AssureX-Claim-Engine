"""Build one canonical dataset from existing AssureX split CSVs.

Usage:
  python build_common_dataset.py --input-dir backend1/data --output backend1/data/common/claim_dataset.csv

The script does not regenerate or relabel records. It validates the existing
train/validation/test records, adds a deterministic Split column, and writes
one canonical raw dataset plus split-specific copies.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from schema import RAW_COLUMNS, validate_record

REQUIRED = RAW_COLUMNS + ["Classification"]

def load(path: Path, split: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing: raise ValueError(f"{path}: missing columns: {missing}")
    errors=[]
    for i, row in df.iterrows():
        e=validate_record(row.to_dict())
        if e: errors.append((i,e))
    if errors:
        raise ValueError(f"{path}: first invalid row {errors[0]}")
    out=df[REQUIRED].copy()
    out.insert(0,"Split",split)
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input-dir",required=True); ap.add_argument("--output",required=True)
    a=ap.parse_args(); root=Path(a.input_dir)
    frames=[load(root/"train.csv","train"),load(root/"validation.csv","validation"),load(root/"test.csv","test")]
    common=pd.concat(frames,ignore_index=True)
    if common[REQUIRED].duplicated().any(): raise ValueError("duplicate complete records detected")
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); common.to_csv(a.output,index=False)
    for split in ("train","validation","test"):
        common[common.Split==split][REQUIRED].to_csv(Path(a.output).with_name(f"{split}.csv"),index=False)
    print({"rows":len(common),"splits":common.Split.value_counts().to_dict(),"labels":common.Classification.value_counts().to_dict()})
if __name__=="__main__": main()
