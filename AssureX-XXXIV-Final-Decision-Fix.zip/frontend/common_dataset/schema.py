"""AssureX XVII — Common Warranty Claim Dataset contract.

Single source-of-truth schema shared by generation, preprocessing, training,
evaluation and inference. It preserves the existing 13 source fields and the
existing three-class labels; six engineered fields remain preprocessing output,
not duplicated into the raw dataset.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

RAW_COLUMNS = [
    "Product_Category", "Product_Age_Months", "Warranty_Duration",
    "Extended_Warranty", "Purchase_Price", "Damage_Type",
    "Repair_History_Count", "Previous_Repair_Unauthorized",
    "Serial_Number_Match", "Missing_Documents_Count",
    "Fault_To_Claim_Delay_Days", "Contradiction_Flag", "Duplicate_Claim_Flag",
]
ENGINEERED_COLUMNS = [
    "Remaining_Warranty_Months", "Out_Of_Warranty", "Documents_Complete",
    "High_Risk_Repair", "Late_Report", "Risk_Score",
]
MODEL_COLUMNS = RAW_COLUMNS + ENGINEERED_COLUMNS
LABELS = ["Invalid Claim", "Valid Claim", "Manual Review"]
CATEGORIES = ["Electronics", "Mobile Devices", "Home Appliances", "Automotive", "Furniture", "Commercial Machinery"]
DAMAGE_TYPES = ["Component Failure", "Screen Crack", "Water Damage", "Wear and Tear", "Accidents", "Misuse", "Defective Components"]

@dataclass(frozen=True)
class DatasetContract:
    version: str = "17.0.0"
    raw_columns: tuple[str, ...] = tuple(RAW_COLUMNS)
    engineered_columns: tuple[str, ...] = tuple(ENGINEERED_COLUMNS)
    model_columns: tuple[str, ...] = tuple(MODEL_COLUMNS)
    labels: tuple[str, ...] = tuple(LABELS)

CONTRACT = DatasetContract()

def validate_record(row: Mapping[str, Any], require_label: bool = True) -> list[str]:
    errors = [f"missing column: {c}" for c in RAW_COLUMNS if c not in row]
    if require_label and "Classification" not in row:
        errors.append("missing column: Classification")
    if errors:
        return errors
    if row["Product_Category"] not in CATEGORIES:
        errors.append("invalid Product_Category")
    if row["Damage_Type"] not in DAMAGE_TYPES:
        errors.append("invalid Damage_Type")
    if require_label and row["Classification"] not in LABELS:
        errors.append("invalid Classification")
    for c in ["Product_Age_Months", "Warranty_Duration", "Purchase_Price", "Repair_History_Count", "Missing_Documents_Count", "Fault_To_Claim_Delay_Days"]:
        try: float(row[c])
        except (TypeError, ValueError): errors.append(f"non-numeric {c}")
    return errors
