# Admin login redirect-loop fix

The previous role guard redirected authenticated users to login.html after *any* Firestore profile-read error. login.html then immediately redirected that same signed-in user back to dashboard, producing a loop. The guard now shows an access-verification error with a Retry option without signing out. The login telemetry write is non-blocking: Firestore failure cannot turn a successful Firebase login into a displayed login failure. Admin page waits for Firebase auth restoration before deciding whether the user is logged out.

Verify Firestore users/{uid} has role `admin`, isActive not false, and that deployed rules allow that account to read its own user profile. Local source tests cannot verify deployed Firebase permissions.
