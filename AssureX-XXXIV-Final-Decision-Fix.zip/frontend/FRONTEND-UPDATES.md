# AssureX Frontend Updates

Updated to close the previously identified partial implementation gaps that can be completed without the external Python/Teachable Machine model files.

## Included updates
- Admin-configurable warranty expiry alert threshold (0–365 days), persisted in Firestore `system_settings/warranty_alert` and cached locally.
- Warranty and dashboard expiry calculations now use the configured threshold instead of a hard-coded 30 days.
- Claim submission, missing-document, status-change and additional-information notification events.
- Expanded administrator metrics: valid/invalid, pending, duplicate flags, model disagreements and average top confidence.
- Expanded analytics: duplicate flags, model disagreements, average confidence, warranty-expiring count, top fault categories and rejection reasons.
- Model comparison helper with configurable Strong/Acceptable/Weak/Disagreement/Uncertain statuses.
- Reviewer workflow now supports `Additional Information Required`.
- Downloadable claim report upgraded to an HTML report containing claim details, model results, confidence comparison, rule/evidence findings, missing documents, contradictions and reviewer information.
- Firestore rules updated for the new `system_settings` collection and user/staff notification creation.
- Added a monitoring import compatibility shim.

## Intentionally not implemented here
The trained Python classifier and Google Teachable Machine model remain external to this frontend archive, so their actual inference cannot be embedded or fabricated here. The frontend is prepared to consume their stored prediction/confidence fields.
