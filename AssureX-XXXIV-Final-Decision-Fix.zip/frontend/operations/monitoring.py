"""Pure monitoring/anomaly rules for AssureX XLVI-L.
No model inference is performed here.
"""
from collections import Counter

VERSION = "50.0.0"


def model_anomalies(python_result=None, teachable_machine_result=None, low_confidence=0.55):
    py = python_result or {}
    tm = teachable_machine_result or {}
    findings = []
    pc = py.get("confidence")
    tc = tm.get("confidence")
    if isinstance(pc, (int, float)) and pc < low_confidence:
        findings.append({"code": "PYTHON_LOW_CONFIDENCE", "severity": "medium", "confidence": pc})
    if isinstance(tc, (int, float)) and tc < low_confidence:
        findings.append({"code": "TM_LOW_CONFIDENCE", "severity": "medium", "confidence": tc})
    if py.get("label") and tm.get("label") and py["label"] != tm["label"]:
        findings.append({"code": "MODEL_DISAGREEMENT", "severity": "high", "python": py["label"], "teachable_machine": tm["label"]})
    return findings


def error_burst(error_codes, threshold=5):
    counts = Counter(str(x) for x in (error_codes or []))
    return [
        {"code": "REPEATED_ERROR", "severity": "medium", "error_code": code, "count": count}
        for code, count in counts.items() if count >= threshold
    ]


def claim_status_anomalies(statuses):
    counts = Counter(str(x or "unknown") for x in (statuses or []))
    findings = []
    total = sum(counts.values())
    if total and counts.get("pending", 0) / total >= 0.75 and total >= 20:
        findings.append({"code": "PENDING_BACKLOG_SPIKE", "severity": "medium", "count": counts["pending"], "total": total})
    if total and (counts.get("rejected", 0) + counts.get("approved", 0)) / total >= 0.95 and total >= 50:
        findings.append({"code": "OUTCOME_DISTRIBUTION_SPIKE", "severity": "low", "total": total})
    return findings


def evaluate_monitoring_snapshot(snapshot):
    """Return findings only; callers decide how/where to persist alerts."""
    findings = []
    findings.extend(model_anomalies(snapshot.get("python_model"), snapshot.get("teachable_machine")))
    findings.extend(error_burst(snapshot.get("recent_error_codes", [])))
    findings.extend(claim_status_anomalies(snapshot.get("claim_statuses", [])))
    return {"engine_version": VERSION, "anomaly_count": len(findings), "findings": findings}
