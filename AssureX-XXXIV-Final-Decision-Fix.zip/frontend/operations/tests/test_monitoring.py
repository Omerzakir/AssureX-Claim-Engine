from monitoring import model_anomalies, error_burst, claim_status_anomalies, evaluate_monitoring_snapshot

def test_model_disagreement_and_low_confidence():
    out = model_anomalies({"label":"Valid Claim","confidence":0.4},{"label":"Invalid Claim","confidence":0.5})
    assert {x["code"] for x in out} == {"PYTHON_LOW_CONFIDENCE","TM_LOW_CONFIDENCE","MODEL_DISAGREEMENT"}

def test_error_burst():
    assert error_burst(["permission-denied"]*5) == [{"code":"REPEATED_ERROR","severity":"medium","error_code":"permission-denied","count":5}]

def test_snapshot():
    out=evaluate_monitoring_snapshot({"claim_statuses":["pending"]*20})
    assert out["anomaly_count"] == 1
    assert out["findings"][0]["code"] == "PENDING_BACKLOG_SPIKE"
