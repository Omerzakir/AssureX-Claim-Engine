# Claim submission fixes

- `claims.html` no longer imports incompatible legacy `app.js` alongside `firebase-auth.js`.
- Notification listener filters by `userId` then sorts in-browser, avoiding the `userId+createdAt` composite index. An index may still be desirable for very large notification histories.
- Claim evidence can reuse the signed-in owner’s already completed exact-hash file; reused items are referenced by document ID and never deleted by claim failure cleanup. This does **not** override file integrity or ownership checks. The reused document's original `claimId` remains unchanged, so use claim `evidence.documentIds` as the source for associations.
- Partial uploads are tracked immediately and best-effort cleaned up on errors; unsaved claim references are no longer deleted.
- Launch with `start-frontend.bat` or `python -m http.server 8080` from the frontend directory; do not open `file:///` URLs.
- Firestore rules are **not** weakened. Publish the provided `firestore.rules.txt` only after reviewing it against your deployed role policy. Existing permission failures can still occur if deployed rules do not authorize the signed-in user.
- Local checks cover syntax and source changes, not live Firebase integration.
